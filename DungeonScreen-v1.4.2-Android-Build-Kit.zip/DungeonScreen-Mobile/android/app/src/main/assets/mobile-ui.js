/* Touch-first navigation around the original DungeonScreen editors. */
(()=>{'use strict';
const $=id=>document.getElementById(id),tabs=['library','editor','preview'];let lastView='library';
function show(view){if(!tabs.includes(view))return;lastView=document.body.dataset.mobileView;document.body.dataset.mobileView=view;for(const btn of document.querySelectorAll('[data-mobile-tab]')){btn.classList.toggle('selected',btn.dataset.mobileTab===view);btn.setAttribute('aria-selected',String(btn.dataset.mobileTab===view))}const nav=$('mobileTabs');if(nav&&nav.hidden)nav.hidden=false;try{sessionStorage.setItem('dungeonscreen-last-mobile-view',view)}catch{};$('mobileProjectName').textContent=$('projectLabel')?.textContent||'No project selected'}
function transferDialog(){const old=$('mobileTransferDialog');if(old){old.remove();return}const wrap=document.createElement('div');wrap.id='mobileTransferDialog';wrap.className='mobile-transfer-overlay';wrap.innerHTML=`<section class="mobile-transfer-card" role="dialog" aria-modal="true" aria-label="Project transfer"><header><h2>Project storage</h2><button data-mobile-close aria-label="Close">×</button></header><p>DungeonScreen uses the same project files as the Windows edition.</p>${window.dsMobile.native?'<button data-mobile-folder>Open existing project folder</button>':''}<button data-mobile-import>Import project ZIP</button><button data-mobile-export>Export current project ZIP</button><small>${window.dsMobile.native?'Choose a project folder using Android Files. Projects remain accessible outside the app.':'Browser projects are stored offline on this device. Export ZIP before clearing browser data or changing phones.'}</small></section>`;document.body.appendChild(wrap);wrap.addEventListener('click',async e=>{if(e.target===wrap||e.target.closest('[data-mobile-close]'))return wrap.remove();if(e.target.closest('[data-mobile-import]')){$('mobileZipInput').click();wrap.remove()}if(e.target.closest('[data-mobile-folder]')){wrap.remove();await openNativeFolder()}if(e.target.closest('[data-mobile-export]')){wrap.remove();await exportZip()}})}
function notify(message,bad=false){const toast=$('toast');if(!toast)return alert(message);toast.textContent=message;toast.style.borderColor=bad?'#cf7777':'#62778d';toast.classList.add('visible');setTimeout(()=>toast.classList.remove('visible'),4800)}
async function importZip(file){if(!file)return;try{const project=await window.dsMobile.importZip(file);notify('Imported '+project.name+'. Opening…');setTimeout(()=>location.reload(),200)}catch(e){notify('Import failed: '+e.message,true)}}
async function exportZip(){try{const fname=await window.dsMobile.exportZip();notify('Exported '+fname)}catch(e){notify('Export failed: '+e.message,true)}}
async function openNativeFolder(){try{const result=await window.dsMobile.chooseExistingFolder();if(result){notify('Opening '+result.project.name);setTimeout(()=>location.reload(),180)}}catch(e){notify('Unable to open folder: '+e.message,true)}}
async function openProjectPicker(){if(window.dsMobile.native){await openNativeFolder()}else{transferDialog()}}
function back(){if($('mobileTransferDialog'))return $('mobileTransferDialog').remove();if(!$('dialog').hidden){$('closeDialog').click();return}if(document.body.dataset.mobileView==='preview')show('editor');else if(document.body.dataset.mobileView==='editor')show('library');else transferDialog()}
function activate(){if(!$('mobileNav'))return;
 for(const btn of document.querySelectorAll('[data-mobile-tab]'))btn.addEventListener('click',()=>show(btn.dataset.mobileTab));
 $('mobileNavToggle').addEventListener('click',()=>{document.body.classList.toggle('mobile-tabs-hidden');$('mobileNavToggle').setAttribute('aria-expanded',String(!document.body.classList.contains('mobile-tabs-hidden')))});
 $('mobileStorage').addEventListener('click',transferDialog);
 $('mobileZipInput').addEventListener('change',e=>{importZip(e.target.files?.[0]);e.target.value=''});
 // Open library entries and newly-created entries in the full-screen editor.
 $('libraryLists').addEventListener('click',e=>{if(e.target.closest('.manager-node-main,[data-create]'))requestAnimationFrame(()=>show('editor'))});
 $('newEntryMenu').addEventListener('click',e=>{if(e.target.closest('[data-create]'))requestAnimationFrame(()=>show('editor'))});
 // The original preview's field locator runs on click bubbling. Switch tabs in capture phase.
 $('previewStage').addEventListener('click',e=>{if(e.target.closest('[data-edit]'))show('editor')},true);
 // Do not offer nonfunctional native window detachment or Windows-only reveal tools.
 for(const el of document.querySelectorAll('[data-detach], [data-act="revealProject"]'))el.hidden=true;
 const menu=$('projectMenu');menu.insertAdjacentHTML('afterbegin','<button data-mobile-transfer>⇄ Project transfer / storage</button>');menu.addEventListener('click',e=>{if(e.target.closest('[data-mobile-transfer]')){menu.hidden=true;transferDialog()}});
 // Mobile web view has no external headless browser capture. PDF uses native Android print.
 for(const b of document.querySelectorAll('[data-act="png"]'))b.hidden=true;
 for(const b of document.querySelectorAll('[data-act="pdf"],[data-act="print"]')){b.textContent='Print / Save PDF';b.dataset.mobilePrint='1';b.removeAttribute('data-act')}
 $('previewMenu').addEventListener('click',e=>{if(e.target.closest('[data-mobile-print]')){e.stopPropagation();$('previewMenu').hidden=true;if(window.dsMobile.native){window.AndroidStorage.printPage()}else window.print()}});
 const observer=new MutationObserver(()=>{if(!$('projectLabel'))return;const name=$('projectLabel').textContent;if($('mobileProjectName').textContent!==name)$('mobileProjectName').textContent=name;const settings=$('settingsTabs');if(settings){const storage=settings.querySelector('[data-tab="storage"]');if(storage)storage.hidden=true;const browser=$('set_browser');if(browser?.closest('.dialog-field'))browser.closest('.dialog-field').hidden=true}});
 observer.observe(document.body,{subtree:true,childList:true,characterData:true});
 show('library');
}
window.dsMobileUI={show,openProjectPicker,back,exportZip,importZip};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',activate,{once:true});else activate();
})();
