/* Optional HTTPS/PWA offline cache. Not used in the native Android app. */
const CACHE='dungeonscreen-mobile-v1.4.0-1';
const ASSETS=['./','./index.html','./forge-base.css','./block-design.css','./dungeon.css','./mobile.css','./jszip.min.js','./mobile-store.js','./dice.js','./forge-core.js','./legacy-state.js','./dungeon.js','./mobile-ui.js','./icon-192.png','./icon-512.png','./manifest.webmanifest'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{if(event.request.method==='GET'&&new URL(event.request.url).origin===self.location.origin){event.respondWith(caches.match(event.request).then(hit=>hit||fetch(event.request)))}});
