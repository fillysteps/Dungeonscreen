package com.darkpilot.dungeonscreen;

import android.app.Activity;
import android.app.PrintManager;
import android.content.Context;
import android.content.Intent;
import android.content.UriPermission;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.provider.DocumentsContract;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/** Offline DungeonScreen wrapper. Uses Android's Storage Access Framework, not a private copy
 * of the campaign. The selected directory has the identical contents as the Windows project. */
public class MainActivity extends Activity {
    private static final int PICK_TREE = 2101;
    private static final int PICK_INPUT = 2102;
    private static final int SAVE_OUTPUT = 2103;
    private WebView webView;
    private Uri tree;
    private ValueCallback<Uri[]> pendingUpload;
    private byte[] pendingExport;
    private String pendingMime;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xff171f2b);
        getWindow().setNavigationBarColor(0xff10151e);
        webView = new WebView(this);
        webView.setBackgroundColor(0xff10151e);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowFileAccessFromFileURLs(false);
        webView.getSettings().setAllowUniversalAccessFromFileURLs(false);
        webView.getSettings().setSupportZoom(false);
        webView.getSettings().setDefaultTextEncodingName("UTF-8");
        webView.addJavascriptInterface(new Bridge(), "AndroidStorage");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !"file".equals(request.getUrl().getScheme());
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (pendingUpload != null) pendingUpload.onReceiveValue(null);
                pendingUpload = callback;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, PICK_INPUT);
                    return true;
                } catch (Exception e) {
                    pendingUpload = null;
                    Toast.makeText(MainActivity.this, "Cannot open file picker", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override public void onBackPressed() {
        if (webView != null) webView.evaluateJavascript("window.dsMobileUI && window.dsMobileUI.back()", null);
        else super.onBackPressed();
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == PICK_INPUT) {
            if (pendingUpload != null) {
                pendingUpload.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
                pendingUpload = null;
            }
            return;
        }
        if (request == PICK_TREE) {
            Uri uri = result == RESULT_OK && data != null ? data.getData() : null;
            if (uri != null) {
                try {
                    int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    getContentResolver().takePersistableUriPermission(uri, flags);
                    tree = uri;
                } catch (Exception e) { uri = null; }
            }
            JSONObject obj = new JSONObject();
            if (uri != null) {
                try { obj.put("uri", uri.toString()); obj.put("name", displayName(docRoot())); }
                catch (Exception ignored) { }
            }
            final String resultJson = uri == null ? "null" : obj.toString();
            webView.evaluateJavascript("window.__mobileChosenFolder && window.__mobileChosenFolder(" + resultJson + ")", null);
            return;
        }
        if (request == SAVE_OUTPUT) {
            if (result == RESULT_OK && data != null && data.getData() != null && pendingExport != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData(), "wt")) {
                    if (out == null) throw new IOException("Unable to open destination");
                    out.write(pendingExport);
                    Toast.makeText(this, "Project ZIP saved", Toast.LENGTH_SHORT).show();
                } catch (Exception e) { Toast.makeText(this, "Export failed: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
            }
            pendingExport = null;
        }
    }

    private Uri docRoot() {
        if (tree == null) throw new IllegalStateException("Open a project folder first");
        return DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree));
    }
    private String displayName(Uri document) throws Exception {
        try (Cursor c = getContentResolver().query(document, new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(0);
        }
        return "Project";
    }
    private static class Child {
        String name, id, mime;
        Child(String n,String i,String m){name=n;id=i;mime=m;}
        boolean directory(){return DocumentsContract.Document.MIME_TYPE_DIR.equals(mime);}
    }
    private List<Child> children(Uri parent) throws Exception {
        List<Child> result = new ArrayList<>();
        Uri dir = DocumentsContract.buildChildDocumentsUriUsingTree(tree, DocumentsContract.getDocumentId(parent));
        String[] cols = {DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_MIME_TYPE};
        try (Cursor c = getContentResolver().query(dir, cols, null, null, null)) {
            if (c != null) while(c.moveToNext()) result.add(new Child(c.getString(0),c.getString(1),c.getString(2)));
        }
        return result;
    }
    private Uri child(Uri parent,String name) throws Exception {
        for(Child f:children(parent)) if(f.name.equals(name))return DocumentsContract.buildDocumentUriUsingTree(tree,f.id);
        return null;
    }
    private boolean safePart(String value) {
        return value.length()>0 && !value.equals(".") && !value.equals("..") && value.indexOf('\\')<0 && value.indexOf('\u0000')<0 && value.indexOf('/')<0;
    }
    private Uri locate(String rawPath,boolean createParents,boolean file) throws Exception {
        if (tree == null) throw new Exception("Select a project folder first");
        if (rawPath == null || rawPath.isEmpty()) return docRoot();
        String[] parts=rawPath.split("/",-1);
        Uri parent=docRoot();
        for(int i=0;i<parts.length;i++) {
            if(!safePart(parts[i]))throw new Exception("Invalid path");
            Uri next=child(parent,parts[i]);
            if(next==null){
                if(!createParents)return null;
                String mime = file && i==parts.length-1 ? "application/octet-stream" : DocumentsContract.Document.MIME_TYPE_DIR;
                next=DocumentsContract.createDocument(getContentResolver(),parent,mime,parts[i]);
                if(next==null)throw new IOException("Could not create "+parts[i]);
            }
            parent=next;
        }
        return parent;
    }
    private JSONObject done(Object data) {JSONObject result = new JSONObject();try{result.put("ok",true);result.put("data",data);}catch(Exception ignored){}return result;}
    private JSONObject failed(Exception e){JSONObject o=new JSONObject();try{o.put("ok",false);o.put("error",e.getMessage());}catch(Exception ignored){}return o;}

    public class Bridge {
        @JavascriptInterface public String fs(String action, String path, String value) {
            try {
                if ("activate".equals(action)) {
                    Uri uri=Uri.parse(value);
                    if (!"content".equals(uri.getScheme())) throw new Exception("Invalid Android folder URI");
                    boolean found=false;
                    for(UriPermission grant:getContentResolver().getPersistedUriPermissions()) if(grant.getUri().equals(uri)) found=true;
                    if(!found)throw new Exception("Folder permission expired. Open the folder again.");
                    tree=uri;
                    return done(true).toString();
                }
                if("exists".equals(action)) return done(locate(path,false,false)!=null).toString();
                if("mkdir".equals(action)) {locate(path,true,false);return done(true).toString();}
                if("list".equals(action)){
                    Uri uri=locate(path,false,false);
                    JSONArray items=new JSONArray();
                    if(uri!=null)for(Child c:children(uri)){
                        JSONObject o=new JSONObject();o.put("name",c.name);o.put("isDir",c.directory());items.put(o);
                    }
                    return done(items).toString();
                }
                if("read".equals(action)){
                    Uri uri=locate(path,false,false);
                    if(uri==null)throw new IOException("File does not exist");
                    try(InputStream input=getContentResolver().openInputStream(uri);ByteArrayOutputStream out=new ByteArrayOutputStream()){
                        if(input==null)throw new IOException("Cannot read selected file");
                        byte[] buffer=new byte[8192];int n;int total=0;
                        while((n=input.read(buffer))>=0){total+=n;if(total>40*1024*1024)throw new IOException("File is too large");out.write(buffer,0,n);}
                        return done(Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP)).toString();
                    }
                }
                if("write".equals(action)) {
                    Uri uri=locate(path,true,true);
                    byte[] raw=Base64.decode(value,Base64.DEFAULT);
                    if(raw.length>40*1024*1024)throw new IOException("File exceeds limit");
                    try(OutputStream output=getContentResolver().openOutputStream(uri,"wt")){
                        if(output==null)throw new IOException("Cannot write selected file");output.write(raw);
                    }
                    return done(true).toString();
                }
                if("delete".equals(action)){
                    Uri uri=locate(path,false,false);
                    return done(uri!=null && DocumentsContract.deleteDocument(getContentResolver(),uri)).toString();
                }
                throw new Exception("Unknown storage operation");
            }catch(Exception e){return failed(e).toString();}
        }
        @JavascriptInterface public void chooseFolder() {
            runOnUiThread(()->{
                try{
                    Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    startActivityForResult(i,PICK_TREE);
                }catch(Exception e){webView.evaluateJavascript("window.__mobileChosenFolder && window.__mobileChosenFolder(null)",null);}
            });
        }
        @JavascriptInterface public void saveFile(String filename,String mime,String payload) {
            try { pendingExport=Base64.decode(payload,Base64.DEFAULT);pendingMime=mime; }
            catch(Exception e){return;}
            runOnUiThread(()->{
                Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(pendingMime);
                i.putExtra(Intent.EXTRA_TITLE,filename);
                startActivityForResult(i,SAVE_OUTPUT);
            });
        }
        @JavascriptInterface public void printPage() {
            runOnUiThread(()->{
                try{PrintManager manager=(PrintManager)getSystemService(Context.PRINT_SERVICE);
                    manager.print("DungeonScreen Preview",webView.createPrintDocumentAdapter("DungeonScreen"),null);
                }catch(Exception e){Toast.makeText(MainActivity.this,"Printing unavailable",Toast.LENGTH_SHORT).show();}
            });
        }
    }
    @Override protected void onDestroy(){
        if(webView!=null)webView.destroy();
        super.onDestroy();
    }
}
