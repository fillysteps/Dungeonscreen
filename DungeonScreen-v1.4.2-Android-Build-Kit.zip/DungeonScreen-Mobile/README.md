# DungeonScreen Mobile

**Android edition of DungeonScreen 1.4**  
Developer: Darkpilot

DungeonScreen Mobile provides the same seven entry types and Campaign file format as the Windows edition, with a layout adapted for touchscreens. The Library, Editor, and Preview occupy separate tabs. The Android edition uses the system folder and file pickers so a Campaign can be copied between devices without converting its entries.

For an overview of the program, read [README-PROGRAM.md](README-PROGRAM.md). This file covers installation and building the Android edition.

## What's in this package

- `android/` — Android Studio project. Its Java WebView wrapper handles Android folder access, image selection, and printing.
- `app/` — mobile web interface and offline dependencies, including the seven DungeonScreen entry editors.
- `.github/workflows/android-debug-apk.yml` — GitHub Actions workflow to compile an installable debug APK.
- `DungeonScreen-Mobile-Offline.html` — experimental single-file browser fallback.
- `LICENSES/` — third-party ZIP-library notices.

**The package contains source code, not a compiled APK.** Java/Android SDK compilation, native folder permissions, and installation on a physical Android device have not been verified in this environment.

## Build an APK with GitHub Actions — phone or computer

1. Sign in at **https://github.com/** and create a repository. A private repository is suitable for personal builds.
2. Extract this ZIP and upload the **contents of the `DungeonScreen-Mobile` folder** to the repository root. The repository must contain `android/` and `.github/workflows/android-debug-apk.yml` at its top level. Uploading the ZIP itself as one file is not sufficient.
3. Open **Actions → Build DungeonScreen Android APK → Run workflow**. If the workflow started automatically following the upload, you can use that run.
4. Once the workflow succeeds, open the completed run's **Artifacts** and download `DungeonScreen-Android-debug-apk`.
5. Extract the artifact, then open `app-debug.apk` on your phone. Follow Android's prompts to allow installation from your Files app.

On a phone, GitHub's **Desktop site** option can make repository file uploads and Actions controls easier to access. The build needs an internet connection on GitHub's runners, but the resulting application is intended to work offline.

The default build is signed with Android's **development/debug key**. It is not a production-signed release. A later build may use a different signing key and require uninstalling the old app before installation; back up Campaign folders first.

## Build with Android Studio

1. Install Android Studio with Android SDK 35, Gradle 8.9, and JDK 17 support.
2. Open the `android` folder as an Android Studio project and allow dependencies to sync.
3. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Find the APK at `android/app/build/outputs/apk/debug/app-debug.apk`.

The application requests no Internet permission; its Java wrapper stores project files only in folders selected through Android's Storage Access Framework.

## Open or transfer a Campaign

To create a Campaign, first choose or create an empty directory in Android's Files app, then use DungeonScreen's New Campaign command and select it. To open an existing Campaign, copy its entire folder to the phone and use Open Folder.

The Campaign must include `forge.project.json`, the entry category folders, artwork, and `dungeonscreen.library.json` if it uses Projects, folder customization, or tags. Existing Forge Campaigns without that supplemental metadata file remain readable.

When direct folder transfer is inconvenient, the mobile application also includes Project ZIP import/export. In the browser-only edition, Campaigns live in browser-managed storage until exported as ZIP files.

## Mobile controls

Use **Library** to browse and organize entries, **Editor** to change the selected entry, and **Preview** to read its formatted display. Tapping text in Preview returns to its matching editor field. The toolbar provides search and entry commands. Long-press or use the `•••` menu for item actions; text fields retain Android's own editing controls.

The inline Projects section groups references without copying the original entries. Expand it with + or collapse it with −; Projects have independent sorting controls. The Characters editor includes quantities, equipment, and linked magic items. The Encounter editor keeps each combatant's state independent. Native detached desktop windows are not part of the mobile interface.

## Testing and compatibility

The editor was exercised in a simulated mobile Chromium viewport using an Android-file-bridge mock. Seven entry types, a linked magic item, an encounter, a Project reference, and ZIP import/export were checked. The Windows Go backend successfully read the generated Campaign. This validates the shared file structure, **not** a complete native Android build.

For further guidance, open the app's **Menu → About** documentation.

**Support:** fillynatarashi@gmail.com

## Inline Projects in 1.4.1

Projects appear above the entry categories, not in a separate mode. Use the + / − icon to expand or collapse them. They retain independent sorting and can reference any entry type. On a phone, these controls are available from the Library tab.

## Inline Projects in 1.4.1

Projects appear above the entry categories, not in a separate mode. Use the + / − icon to expand or collapse them. They retain independent sorting and can reference any entry type. On a phone, these controls are available from the Library tab.

## Fixes in v1.4.2

Searching the library now reveals entries inside collapsed folders and respects selected tags. Locate Original opens the canonical entry path. Editor search expands closed optional panels, and the Load submenu searches the complete entry list. No Campaign data migration is required.
