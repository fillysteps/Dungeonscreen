# Build DungeonScreen for Android with GitHub Actions

**DungeonScreen v1.4.2 · Android APK build guide**  
**Developer:** Darkpilot

This guide explains how to build the Android edition of DungeonScreen using a GitHub repository and GitHub Actions. It works from an Android phone; no computer, Android Studio, or local development tools are required.

The kit contains:

| File | Purpose |
| --- | --- |
| `DungeonScreen-Android-Source-v1.4.2.zip` | Complete v1.4.2 Android source project. Upload this file **without extracting it** to GitHub. |
| `build-dungeonscreen-apk.yml` | GitHub Actions workflow. Its contents must be placed in `.github/workflows/build-dungeonscreen-apk.yml` in the repository. |
| `GITHUB-ANDROID-BUILD-GUIDE.md` | This guide. |

The complete Android project uses **Java 17**, **Android Gradle Plugin 8.7.3**, **Gradle 8.9**, and **Android SDK 35**. The workflow installs the required toolchain on a GitHub-hosted machine, compiles the app, and provides a downloadable debug APK.

## Step 1 — Prepare the files on your phone

1. Download and extract `DungeonScreen-v1.4.2-GitHub-APK-Build-Kit.zip` using your phone's Files application.
2. Find these two files inside the extracted folder:
   - `DungeonScreen-Android-Source-v1.4.2.zip`
   - `build-dungeonscreen-apk.yml`
3. **Do not extract the source ZIP.** The workflow extracts it automatically when GitHub builds the app.

If Android's file manager hides folders beginning with a dot (`.github`), that is expected. You do **not** need to locate the hidden folder in the supplied kit to follow this method.

## Step 2 — Create a GitHub repository

1. Open [github.com/new](https://github.com/new) in your mobile browser and sign in.
2. Enter a name such as `DungeonScreen-Android`.
3. Choose **Private** for a personal build, or Public if you want to share the source.
4. Create the repository with a README so that it starts with a `main` branch.

On a small screen, the browser's **Desktop site** option can make GitHub's repository tools easier to find.

## Step 3 — Upload the Android source ZIP

1. Open your new repository's **Code** page.
2. Choose **Add file → Upload files** (or the repository's upload link).
3. Select `DungeonScreen-Android-Source-v1.4.2.zip` from your phone's extracted build kit.
4. Commit the upload to the repository's default branch.

The repository root must now contain this **exact filename**:

`DungeonScreen-Android-Source-v1.4.2.zip`

**Do not upload only the combined build-kit ZIP.** The GitHub workflow looks for the inner Android source ZIP by name.

## Step 4 — Add the workflow YAML file

1. Return to your repository's **Code** page and choose **Add file → Create new file**.
2. In the filename box, enter this full path:

   `.github/workflows/build-dungeonscreen-apk.yml`

   GitHub will create the `.github` and `workflows` directories automatically.
3. Open the supplied `build-dungeonscreen-apk.yml` in a text editor on your phone. Copy **all** of its contents and paste them into GitHub's new-file editor.
4. Commit the new file to the default branch (`main` or `master`).

**Important:** Uploading `build-dungeonscreen-apk.yml` as an ordinary file at the repository root will not make GitHub run it. The workflow must live under `.github/workflows/`.

Your repository will now contain:

```text
DungeonScreen-Android/
├── .github/
│   └── workflows/
│       └── build-dungeonscreen-apk.yml
├── DungeonScreen-Android-Source-v1.4.2.zip
└── README.md
```

## Step 5 — Run the APK build

1. Open the repository's **Actions** tab.
2. If GitHub asks you to enable workflows for the repository, follow that prompt.
3. Choose **Build DungeonScreen Android APK** from the workflow list.
4. Choose **Run workflow**, keep the default branch selected, and confirm.

The workflow may also start automatically when you first commit the YAML or source ZIP. The first build downloads Gradle and Android dependencies on GitHub's servers and can take longer than subsequent builds.

The build is successful when the workflow run shows a green check mark. If it fails, open the failed step to read its error log.

## Step 6 — Download and install the APK

1. Open the completed workflow run in **Actions**.
2. Scroll to **Artifacts** and download `DungeonScreen-v1.4.2-Android-APK`.
3. Open the downloaded artifact ZIP in your phone's Files application.
4. Extract `DungeonScreen-v1.4.2-debug.apk`.
5. Tap the APK, then follow Android's prompts to install it. Your phone may require you to approve installing apps from the Files app or browser.
6. Launch **DungeonScreen** from your app drawer.

The APK is built with an **Android debug/development certificate**. It is suitable for personal testing, but it is **not a production-signed release**. Builds made on different GitHub runners may have different debug signatures, so a later APK might not install over an earlier one. If Android reports a signature mismatch, back up Campaign data before uninstalling any previously installed copy.

## What the build does — and does not do

The build compiles the v1.4.2 Android app and packages its offline HTML/CSS/JavaScript editor into an Android WebView wrapper. It does not build the Windows executable, upload Campaign data, or enable cloud synchronization. A compiled APK can operate offline using Android's folder and file pickers.

The workflow **has been checked against the source tree and configuration**, but it has not been executed on GitHub in this environment. Successful compilation does not, by itself, verify runtime permissions, file operations, or behavior on every Android device.

## Troubleshooting

**I can't see the workflow in Actions.** Check that the file is committed at `.github/workflows/build-dungeonscreen-apk.yml` on the repository's default branch. A YAML file in the root directory will not appear as a workflow. Refresh the Actions tab, and check whether workflows are enabled for your repository.

**The Run workflow button is missing.** Make sure the YAML has been committed to the default branch. Use the workflow page rather than the general list of runs. On mobile, try the browser's Desktop site view.

**The workflow says it can't find the Android source ZIP.** Upload `DungeonScreen-Android-Source-v1.4.2.zip` to the repository root, exactly as named. Do not upload the outer build-kit ZIP instead.

**The ZIP does not contain an Android project.** Use the source ZIP supplied with this v1.4.2 kit. Do not substitute the Windows source archive or a different-version ZIP.

**The build fails during Java, Gradle, or SDK installation.** Open the failed GitHub Actions step and inspect its log. If the GitHub-hosted runner has a temporary download failure, rerunning the job may help. Persistent compilation errors need to be addressed in the project or workflow.

**The build succeeds but I can't find the APK.** Download the artifact attached to the completed run; the APK is inside that ZIP. It is **not** automatically published under GitHub Releases.

**Android won't install the APK.** Confirm that you extracted the APK from the artifact ZIP and that your device is compatible (Android 8.0 or newer). If an older DungeonScreen build is installed, a different debug-signing certificate can cause an update conflict. Back up Campaigns before uninstalling an existing installation.

**How do I build an updated version later?** Replace the source ZIP in the repository with the new Android source and adjust the workflow's expected ZIP filename if it changes, then run the workflow again. The latest APK will appear under that run's Artifacts.

## Project compatibility

The Android application and Windows DungeonScreen use the same Campaign structure. To move a Campaign between devices, copy its **complete folder**, including entry JSON files, artwork, `forge.project.json`, and `dungeonscreen.library.json` when present. Campaign transfer is manual and not a live sync service.

For feature instructions after installing the app, open **Menu → About** in DungeonScreen.

**Developer:** Darkpilot  
**Support:** fillynatarashi@gmail.com
