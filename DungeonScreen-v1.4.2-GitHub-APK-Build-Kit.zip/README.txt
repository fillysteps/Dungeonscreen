DungeonScreen v1.4.2 — Phone-friendly GitHub APK build kit

1. Read GITHUB-ANDROID-BUILD-GUIDE.md.
2. Upload DungeonScreen-Android-Source-v1.4.2.zip to your repository root.
3. Create .github/workflows/build-dungeonscreen-apk.yml using the supplied YAML.
4. Run the workflow from GitHub Actions and download its APK artifact.

The source ZIP should stay compressed when uploaded.
