from playwright.sync_api import sync_playwright
from pathlib import Path
import requests,json,traceback,time
root=Path('/mnt/data/DungeonScreen-Development'); url='http://127.0.0.1:35793/api'
def py_api(req):
 r=requests.post(url,json=req,headers={'X-DungeonScreen':'local-ui','Origin':'http://127.0.0.1:35793'},timeout=10,proxies={'http':'','https':''});return {'status':r.status_code,'data':r.json()}
def click_menu(page,menu,action):
 page.locator(f'[data-menu="{menu}"]').click();page.locator(f'#{menu} [data-act="{action}"]').click()
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-web-security'])
 page=browser.new_page(viewport={'width':1650,'height':920},accept_downloads=True)
 errors=[];console=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('console',lambda x:console.append(x.text) if x.type=='error' else None)
 page.expose_function('py_api',py_api);page.set_content((root/'app/index.html').read_text(),wait_until='domcontentloaded')
 page.evaluate('''() => {window.fetch=async (url,opts)=>{const req=JSON.parse(opts.body);const r=await window.py_api(req);return {ok:r.status<400,status:r.status,json:async()=>r.data}};}''')
 for f in ['forge-base.css','block-design.css','dungeon.css']:page.add_style_tag(content=(root/'app'/f).read_text())
 for f in ['dice.js','forge-core.js','legacy-state.js','dungeon.js']:page.add_script_tag(content=(root/'app'/f).read_text())
 page.wait_for_timeout(1000)
 # Note
 page.locator('#createEntry').click();page.locator('#newEntryMenu [data-create="note"]').click()
 page.locator('#n_name').fill('History of Fausthold');page.locator('#n_text').fill('Faust XI founded the watchtower.')
 page.locator('#addNoteSection').click();page.locator('#noteSections [data-part=name]').fill('The Blacksmiths');page.locator('#noteSections [data-part=text]').fill('Gorn and Woulder disagree.')
 page.wait_for_timeout(350)
 assert page.locator('#outputContainer').inner_text().find('Faust XI')!=-1
 page.locator('#outputContainer .reader-section').click()
 page.wait_for_timeout(350)
 assert page.locator('#noteSections textarea:focus').count()==1
 page.keyboard.press('Control+f');assert page.locator('#editorSearch:focus').count()==1
 page.locator('#editorSearch').fill('Woulder');print('note search counter',page.locator('#searchCounter').inner_text())
 page.locator('#editorSearch').fill('Gorn');assert page.locator('#searchCounter').inner_text()=='1/1'
 click_menu(page,'editorMenu','save');page.wait_for_timeout(500)
 print('note saved',page.locator('#libraryLists .library-entry').count())
 # Quest
 page.locator('#newEntryMenu').evaluate('(el)=>el.hidden=false');page.locator('#newEntryMenu [data-create="quest"]').click()
 page.locator('#q_name').fill('The Red Passage');page.locator('#q_source').fill('Baron Faust XIV');page.locator('#q_xp').fill('2500');page.locator('#q_gold').fill('750')
 page.locator('#addQuestSection').click();page.locator('#questSections [data-part=name]').fill('Investigate the Road');page.locator('#questSections [data-part=text]').fill('Follow the ash trail.')
 page.locator('#questSections [data-part=done]').check()
 page.wait_for_timeout(350)
 print('quest preview',page.locator('#outputContainer').inner_text()[:250]);assert 'Investigate the Road' in page.locator('#outputContainer').inner_text()
 click_menu(page,'editorMenu','save');page.wait_for_timeout(400)
 # Spell
 page.locator('#createEntry').click();page.locator('#newEntryMenu [data-create="spell"]').click()
 page.locator('#s_name').fill('Astral Rupture');page.locator('#s_school').select_option('Evocation');page.locator('#s_level').select_option('5');page.locator('#s_description').fill('Deal 6d8 radiant damage.')
 page.wait_for_timeout(400);assert 'Astral Rupture' in page.locator('#outputContainer').inner_text()
 click_menu(page,'editorMenu','save');page.wait_for_timeout(400)
 # Item
 page.locator('#createEntry').click();page.locator('#newEntryMenu [data-create="item"]').click()
 page.locator('#i_name').fill('Frost Fang');page.locator('#i_type').select_option('weapon');page.locator('#i_weaponDmg').fill('1d8+2')
 click_menu(page,'editorMenu','save');page.wait_for_timeout(400)
 # Encounter
 page.locator('#createEntry').click();page.locator('#newEntryMenu [data-create="encounter"]').click()
 page.locator('#e_name').fill('Bleedgulch Ambush');page.locator('#addEncounterCreature').click()
 print('select creature options',page.locator('#chooseCreatureResults button').count())
 page.locator('#chooseCreatureResults button').first.click();page.wait_for_timeout(350)
 print('errors after add', errors, console[-5:]); print('toast',page.locator('#toast').inner_text());print('dialog rows',page.locator('#chooseCreatureResults button').count())
 print('combat rows',page.locator('#encounterCreatures .combatant-row').count())
 assert page.locator('#encounterCreatures .combatant-row').count()==1
 page.locator('#dialogFooter button').last.click() # Done
 page.locator('#cm_hp').fill('12');page.locator('#cm_hp').dispatch_event('change')
 page.locator('#cm_tempHp').fill('4');page.locator('#cm_tempHp').dispatch_event('change')
 page.locator('#cm_condition').select_option('Poisoned');page.locator('#cm_addCondition').click()
 page.wait_for_timeout(350)
 print('encounter preview',page.locator('#outputContainer').inner_text()[:350])
 assert 'Poisoned' in page.locator('#outputContainer').inner_text()
 click_menu(page,'editorMenu','save');page.wait_for_timeout(400)
 page.locator('#libraryLists .library-entry').filter(has_text='Bleedgulch Ambush').first.click();page.wait_for_timeout(400)
 assert page.locator('#cm_hp').input_value()=='12'
 page.locator('#instanceEditor').click();print('instance fields',page.locator('[id^=inst_]').count());assert page.locator('[id^=inst_]').count()>20
 page.locator('#inst_c_ac').fill('18');page.locator('#dialogFooter button.primary').click()
 assert page.locator('#cm_ac').input_value()=='18'
 # Settings modal
 click_menu(page,'projectMenu','settings');page.locator('#set_uiTheme').select_option('frost');page.locator('#dialogFooter .primary').click();page.wait_for_timeout(200)
 print('ui theme',page.locator('body').get_attribute('class'))
 # Screenshots
 page.screenshot(path=str(root/'smoke-encounter.png'))
 print('errors',errors,'console',console[:10]);assert not errors
 browser.close()
