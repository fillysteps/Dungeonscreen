from playwright.sync_api import sync_playwright
from pathlib import Path
import requests,json,traceback
root=Path('/mnt/data/DungeonScreen-Development')
url='http://127.0.0.1:39093/api'
def py_api(req):
 try:
  r=requests.post(url,json=req,headers={'X-DungeonScreen':'local-ui','Origin':'http://127.0.0.1:39093'},timeout=10,proxies={'http':'','https':''})
  return {'status':r.status_code,'data':r.json()}
 except Exception as e:
  print('py_api error',e);return {'status':500,'data':{'error':str(e)}}
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-web-security'])
 page=browser.new_page(viewport={'width':1640,'height':920})
 errors=[];logs=[]
 page.on('pageerror',lambda e: errors.append(str(e)))
 page.on('console',lambda msg:logs.append(msg.text) if msg.type=='error' else None)
 page.expose_function('py_api',py_api)
 html=(root/'app/index.html').read_text()
 page.set_content(html,wait_until='domcontentloaded')
 page.evaluate('''() => {window.fetch=async (url,opts)=>{const req=JSON.parse(opts.body);const r=await window.py_api(req);return {ok:r.status<400,status:r.status,json:async()=>r.data}};}''')
 for f in ['forge-base.css','block-design.css','dungeon.css']:
  page.add_style_tag(content=(root/'app'/f).read_text())
 for f in ['dice.js','forge-core.js','legacy-state.js','dungeon.js']:
  page.add_script_tag(content=(root/'app'/f).read_text())
 page.wait_for_timeout(1200)
 print('start errors',errors)
 print('start heading',page.locator('#editorTitle').inner_text())
 page.screenshot(path=str(root/'smoke-initial.png'))
 print('click new project')
 page.locator('#createProject').click()
 page.wait_for_timeout(200)
 print('dialog',page.locator('#dialogTitle').inner_text())
 page.locator('#dialogInput').fill('DungeonScreen QA')
 page.locator('#dialogFooter button.primary').click()
 page.wait_for_timeout(400)
 print('new project:',page.locator('#projectLabel').inner_text())
 page.locator('#c_name').fill('Brood Bird')
 page.locator('#c_ac').fill('14')
 page.locator('#c_hp').fill('24 (3d6+6)')
 page.locator('#c_cr').fill('1')
 page.locator('button').filter(has_text='Add Trait').first.click()
 page.locator('[id^="c_traits_name_"]').first.fill('Sudden Aggression')
 page.locator('[id^="c_traits_desc_"]').first.fill('When hit, this creature deals an extra 2d6 damage.')
 page.wait_for_timeout(400)
 print('preview',page.locator('#outputContainer').inner_text()[:300])
 page.locator('[data-menu="editorMenu"]').click()
 page.locator('#editorMenu [data-act="save"]').click()
 page.wait_for_timeout(900)
 print('saved count',page.locator('#libraryLists .library-entry').count())
 page.screenshot(path=str(root/'smoke-creature.png'))
 print('errors',errors,'logs',logs[:8])
 browser.close()
