package main

import (
	"bytes"
	"errors"
	"fmt"
	"image"
	"image/draw"
	"image/png"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"time"
)

var renderMu sync.Mutex
var renderPages = map[string]string{}
var serverAddress string

func exportPageHTML(preview string, width int) string {
	styles := []string{}
	for _, f := range []string{"forge-base.css", "block-design.css", "dungeon.css"} {
		b, _ := webFiles.ReadFile("app/" + f)
		styles = append(styles, string(b))
	}
	// The app has already HTML-escaped authored content in the preview.
	return fmt.Sprintf(`<!doctype html><html><head><meta charset="utf-8"><style>%s</style><style>
   html,body{padding:0!important;margin:0!important;overflow:visible!important;background:transparent!important;height:auto!important;width:%dpx!important}
   #outputContainer{width:%dpx!important;max-width:none!important;display:block!important;padding:0!important;margin:0!important}
   #outputContainer>#exportTarget{margin:0!important;width:100%%!important;max-width:none!important;box-shadow:none!important;border-radius:0!important}
   .preview-linked:hover{background:none!important;box-shadow:none!important}
   @page{size:letter;margin:12mm}
   @media print{html,body{background:white!important}#outputContainer>#exportTarget{break-inside:auto}}
   </style></head><body><div id="outputContainer">%s</div></body></html>`, strings.Join(styles, "\n"), width, width, preview)
}
func browserExecutable() (string, error) {
	if runtime.GOOS == "windows" {
		paths := []string{filepath.Join(os.Getenv("PROGRAMFILES(X86)"), "Microsoft", "Edge", "Application", "msedge.exe"), filepath.Join(os.Getenv("PROGRAMFILES"), "Microsoft", "Edge", "Application", "msedge.exe"), filepath.Join(os.Getenv("PROGRAMFILES"), "Google", "Chrome", "Application", "chrome.exe"), filepath.Join(os.Getenv("LOCALAPPDATA"), "Google", "Chrome", "Application", "chrome.exe")}
		for _, p := range paths {
			if info, e := os.Stat(p); e == nil && !info.IsDir() {
				return p, nil
			}
		}
	}
	for _, name := range []string{"chromium", "google-chrome", "microsoft-edge", "msedge"} {
		if p, e := exec.LookPath(name); e == nil {
			return p, nil
		}
	}
	return "", errors.New("Edge or Chrome is required for image/PDF exports")
}
func exportBrowser(root, name, format, html string, width, height int) (any, error) {
	if format != "png" && format != "pdf" {
		return nil, errors.New("Unsupported export format")
	}
	if width < 200 || width > 3000 || height < 100 || height > 22000 {
		return nil, errors.New("Preview dimensions are unsupported")
	}
	if len(html) < 10 || len(html) > 4*1024*1024 || !strings.Contains(html, "id=\"exportTarget\"") {
		return nil, errors.New("Preview was not supplied")
	}
	if strings.Contains(strings.ToLower(html), "<script") {
		return nil, errors.New("Scripts are not allowed in exports")
	}
	bin, e := browserExecutable()
	if e != nil {
		return nil, e
	}
	folder := filepath.Join(root, "Exports")
	if e := os.MkdirAll(folder, 0755); e != nil {
		return nil, e
	}
	filename := slug(name) + "." + format
	dest := filepath.Join(folder, filename)
	key := randomHex(16)
	renderMu.Lock()
	renderPages[key] = exportPageHTML(html, width)
	renderMu.Unlock()
	defer func() { renderMu.Lock(); delete(renderPages, key); renderMu.Unlock() }()
	tmpDir, e := os.MkdirTemp("", "dungeonscreen-render-")
	if e != nil {
		return nil, e
	}
	defer os.RemoveAll(tmpDir)
	temp := filepath.Join(tmpDir, filename)
	url := "http://" + serverAddress + "/render/" + key
	args := []string{"--headless=new", "--disable-gpu", "--hide-scrollbars", "--no-first-run", "--no-default-browser-check", "--disable-extensions", "--disable-features=TranslateUI", "--no-proxy-server", "--user-data-dir=" + filepath.Join(tmpDir, "profile"), "--virtual-time-budget=1500"}
	if runtime.GOOS != "windows" {
		args = append(args, "--no-sandbox")
	}
	if format == "png" {
		args = append(args, fmt.Sprintf("--window-size=%d,%d", width+18, height+128), "--screenshot="+temp)
	} else {
		args = append(args, "--no-pdf-header-footer", "--print-to-pdf="+temp)
	}
	args = append(args, url)
	cmd := exec.Command(bin, args...)
	var output bytes.Buffer
	cmd.Stderr = &output
	cmd.Stdout = &output
	done := make(chan error, 1)
	go func() { done <- cmd.Run() }()
	select {
	case e = <-done:
	case <-time.After(28 * time.Second):
		_ = cmd.Process.Kill()
		return nil, errors.New("Browser export timed out")
	}
	if _, statErr := os.Stat(temp); statErr != nil {
		return nil, fmt.Errorf("Browser export did not create a file: %v — %s", e, truncateError(output.String()))
	}
	if format == "png" {
		f, e := os.Open(temp)
		if e != nil {
			return nil, e
		}
		img, e := png.Decode(f)
		f.Close()
		if e != nil {
			return nil, e
		}
		b := img.Bounds()
		if b.Dx() < width || b.Dy() < height {
			return nil, fmt.Errorf("Browser screenshot too small (%d×%d)", b.Dx(), b.Dy())
		}
		result := image.NewRGBA(image.Rect(0, 0, width, height))
		draw.Draw(result, result.Bounds(), img, image.Point{}, draw.Src)
		out, e := os.Create(dest)
		if e != nil {
			return nil, e
		}
		e = png.Encode(out, result)
		errClose := out.Close()
		if e != nil {
			return nil, e
		}
		if errClose != nil {
			return nil, errClose
		}
	} else {
		buf, e := os.ReadFile(temp)
		if e != nil {
			return nil, e
		}
		if !bytes.HasPrefix(buf, []byte("%PDF-")) {
			return nil, errors.New("The PDF output was invalid")
		}
		if e = os.WriteFile(dest, buf, 0644); e != nil {
			return nil, e
		}
	}
	return map[string]any{"path": dest, "format": format}, nil
}
func truncateError(s string) string {
	if len(s) > 650 {
		s = s[len(s)-650:]
	}
	return s
}
func renderHandler(w http.ResponseWriter, r *http.Request) {
	key := strings.TrimPrefix(r.URL.Path, "/render/")
	renderMu.Lock()
	html, ok := renderPages[key]
	renderMu.Unlock()
	if !ok {
		http.NotFound(w, r)
		return
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	fmt.Fprint(w, html)
}
func listenerAddress(l net.Listener) { serverAddress = l.Addr().String() }
