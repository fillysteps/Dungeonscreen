from pathlib import Path
from playwright.sync_api import sync_playwright
import json
ROOT=Path(__file__).resolve().parents[1] / 'app'
OUT=Path(__file__).resolve().parent

def doc(type,id,name):
 return dict(type=type,id=id,name=name,color='#8b82bc',updatedAt='2026-11-20T12:00:00Z',createdAt='2026-11-20T12:00:00Z',state={'mode':type,'fields':{},'data':{}})
docs=[doc('creature','1111111111111111','Brood Bird'),doc('item','2222222222222222','Sunstone Sword'),doc('note','3333333333333333','Session Notes')]
meta={'version':1,'folders':[],'placements':{},'labels':{},'projects':[{'id':'proj-1','name':'Session Twelve','color':'#a797c8','lastOpened':100,'order':0},{'id':'proj-2','name':'Fausthold','color':'#a797c8','lastOpened':200,'order':1}], 'prjFolders':[],'references':[{'id':'ref-1','projectId':'proj-1','folderId':'','entryType':'creature','entryId':'1111111111111111','order':0}],'categories':{}}
prefs={'sort':'modified','uiTheme':'midnight','showThumbs':True,'projectSort':'manual'}
def main():
 with sync_playwright() as p:
  browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-web-security'])
  page=browser.new_page(viewport={'width':1450,'height':900})
  errors=[];console=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.on('console',lambda e:console.append(e.text) if e.type=='error' else None)
  page.set_content((ROOT/'index.html').read_text(),wait_until='domcontentloaded')
  page.evaluate('''({docs,meta,prefs})=>{
    window.__DSDATA={docs,meta,prefs};
    window.fetch=async (_url, options)=>{
      const q=JSON.parse(options.body||'{}'),s=window.__DSDATA;
      let data;
      if(q.action==='session')data={project:{name:'Demo Campaign',path:'/tmp/demo'},recent:[],settings:s.prefs};
      else if(q.action==='list')data=s.docs;
      else if(q.action==='libraryMeta'){if(q.library)s.meta=q.library;data=s.meta;}
      else if(q.action==='settings'){Object.assign(s.prefs,q.settings||{});data=s.prefs;}
      else if(q.action==='detach')data={ok:true};
      else if(q.action==='load')data=s.docs.find(x=>x.id===q.id);
      else if(q.action==='save'){data=q.document;}
      else data={};
      return {ok:true,status:200,json:async()=>({ok:true,data})};
    };
  }''', {'docs':docs,'meta':meta,'prefs':prefs})
  for f in ['forge-base.css','block-design.css','dungeon.css']:page.add_style_tag(content=(ROOT/f).read_text())
  for f in ['dice.js','forge-core.js','legacy-state.js','dungeon.js']:page.add_script_tag(content=(ROOT/f).read_text())
  page.wait_for_timeout(600)
  assert page.locator('#managerTabs').count()==0,'Old mode switch still exists'
  assert page.locator('.projects-peek .peek-row').count()==2
  assert page.locator('.projects-peek .peek-expand').inner_text().strip()=='+'
  assert page.locator('.projects-peek .peek-expand').get_attribute('title')=='Expand'
  assert page.locator('#libraryLists .library-group').count()==8 # 7 categories + Projects
  page.screenshot(path=str(OUT/'DungeonScreen-1.4.1-collapsed.png'))
  page.locator('.projects-peek .peek-expand').click()
  page.wait_for_timeout(380)
  assert page.locator('.projects-peek .peek-expand').inner_text().strip()=='−'
  assert page.locator('.projects-peek #projectSort').count()==1
  assert page.locator('.projects-peek .manager-node').count()==2
  assert page.locator('.library-group').count()==8
  page.locator('.projects-peek .manager-node-main').filter(has_text='Session Twelve').click()
  page.wait_for_timeout(300)
  assert page.locator('.projects-peek .folder-body .manager-node').count()==1
  assert page.locator('#libraryLists .library-group').count()==8
  assert 'Brood Bird' in page.locator('.projects-peek .folder-body').inner_text()
  assert page.locator('#librarySort').input_value()=='modified'
  page.locator('#projectSort').select_option('name')
  page.wait_for_timeout(150)
  assert page.locator('#projectSort').input_value()=='name'
  assert page.locator('#librarySort').input_value()=='modified'
  assert page.evaluate('window.__DSDATA.prefs.projectSort')=='name'
  row=page.locator('.projects-peek .manager-node').first
  row.evaluate("el=>el.classList.add('drag-sway')")
  assert float(row.evaluate('el=>getComputedStyle(el).opacity'))<=0.6
  assert float(row.evaluate('el=>getComputedStyle(el).borderTopLeftRadius.replace("px","")'))>=10
  row.evaluate("el=>el.classList.remove('drag-sway')")
  page.screenshot(path=str(OUT/'DungeonScreen-1.4.1-expanded.png'))
  page.locator('.projects-peek .peek-expand').click()
  page.wait_for_timeout(340)
  assert page.locator('.projects-peek .peek-row').count()==2
  assert page.locator('.projects-peek .peek-expand').get_attribute('aria-label')=='Expand Projects'
  # Wider library with both other panels detached still has inline Projects, not a mode switch.
  page.locator('[data-detach="editor"]').click();page.wait_for_timeout(180)
  page.locator('[data-detach="preview"]').click();page.wait_for_timeout(220)
  assert page.locator('#libraryLists.manager-columns-active').count()==1
  assert page.locator('.manager-column .projects-peek').count()==1
  assert page.locator('.wide-categories .column-root').count()==7
  page.locator('.manager-column .projects-peek .peek-row').filter(has_text='Session Twelve').click()
  page.wait_for_timeout(200)
  assert page.locator('.manager-column').count()>=2
  assert 'Brood Bird' in page.locator('.manager-column').nth(1).inner_text()
  assert page.locator('.wide-categories .column-root').count()==7
  page.screenshot(path=str(OUT/'DungeonScreen-1.4.1-wide.png'))
  assert not errors,errors
  print('PASS: no mode switch; inline expansion; independent sorting; linked project entry; rounding and transparency; wide layout',flush=True)
  print('console:',console[:4], 'errors:', errors)
  browser.close()
if __name__=='__main__':main()
