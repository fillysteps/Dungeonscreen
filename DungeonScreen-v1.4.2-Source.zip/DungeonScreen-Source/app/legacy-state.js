// Original Forge state model for 2014 creatures and magic items.
  function gatherState() {
    const state = { mode: currentMode, version: 2 };
    state.fields = {};
    document.querySelectorAll('#creatureEditor input[id], #creatureEditor select[id], #creatureEditor textarea[id]').forEach(el => {
      if (el.type === 'file') return;
      state.fields[el.id] = el.type === 'checkbox' ? el.checked : el.value;
    });
    document.querySelectorAll('#itemEditor input[id], #itemEditor select[id], #itemEditor textarea[id]').forEach(el => {
      if (el.type === 'file') return;
      state.fields[el.id] = el.type === 'checkbox' ? el.checked : el.value;
    });
    state.spellLevels = [];
    for (let i = 0; i < 10; i++) {
      state.spellLevels.push({
        checked: document.getElementById(`c_spellToggle_${i}`).checked,
        slots: i > 0 ? document.getElementById(`c_spellSlots_${i}`).value : '',
        spells: document.getElementById(`c_spellList_${i}`).value
      });
    }
    state.weaponProps = [];
    weaponProperties.forEach((p, i) => { state.weaponProps.push(document.getElementById(`i_wprop_${i}`).checked); });
    ['c_traits','c_actions','c_bonus','c_reactions','c_legendary','c_lair'].forEach(type => { state[type] = collectEntries(type); });
    state.i_effects = collectItemEntries('i_effectsContainer', 'i_eff');
    state.i_spells = collectItemEntries('i_spellsContainer', 'i_spell');
    return state;
  }

  function restoreState(state) {
    if (!state || !state.fields) return;
    if (state.mode) setMode(state.mode);
    for (const [id, val] of Object.entries(state.fields)) {
      const el = document.getElementById(id);
      if (!el) continue;
      if (el.type === 'checkbox') {
        el.checked = val;
        // Sections are synchronized explicitly after field restoration.
      } else el.value = val;
    }
    if (state.spellLevels) {
      state.spellLevels.forEach((sl, i) => {
        const cb = document.getElementById(`c_spellToggle_${i}`);
        cb.checked = sl.checked;
        document.getElementById(`c_spellRow_${i}`).classList.toggle('active', sl.checked);
        if (i > 0) document.getElementById(`c_spellSlots_${i}`).value = sl.slots;
        document.getElementById(`c_spellList_${i}`).value = sl.spells;
      });
    }
    if (state.weaponProps) state.weaponProps.forEach((checked, i) => { document.getElementById(`i_wprop_${i}`).checked = checked; });
    ['c_traits','c_actions','c_bonus','c_reactions','c_legendary','c_lair'].forEach(type => {
      document.getElementById(type + 'Container').innerHTML = '';
      if (state[type]) state[type].forEach(entry => {
        addEntry(type);
        const id = counters[type] - 1;
        document.getElementById(`${type}_name_${id}`).value = entry.name || '';
        document.getElementById(`${type}_desc_${id}`).value = entry.desc || '';
        const costEl = document.getElementById(`${type}_cost_${id}`);
        if (costEl) costEl.value = entry.cost || '';
      });
    });
    document.getElementById('i_effectsContainer').innerHTML = '';
    if (state.i_effects) state.i_effects.forEach(entry => {
      addItemEffect(); const id = counters.i_effects - 1;
      document.getElementById(`i_eff_name_${id}`).value = entry.name || '';
      document.getElementById(`i_eff_desc_${id}`).value = entry.desc || '';
      document.getElementById(`i_eff_cost_${id}`).value = entry.cost || '';
    });
    document.getElementById('i_spellsContainer').innerHTML = '';
    if (state.i_spells) state.i_spells.forEach(entry => {
      addItemSpell(); const id = counters.i_spells - 1;
      document.getElementById(`i_spell_name_${id}`).value = entry.name || '';
      document.getElementById(`i_spell_cost_${id}`).value = entry.cost || '';
      document.getElementById(`i_spell_level_${id}`).value = entry.level || '';
    });
    onItemTypeChange();
    ['c_spellcasting','c_legendary','c_lair','i_attunement','i_charges','i_destroyOnZero','i_spells','i_curse','i_sentient'].forEach(key => {
      const cb = document.getElementById(key + 'Toggle') || document.getElementById(key);
      const id = key === 'i_destroyOnZero' ? 'i_destroyDetails' : key + 'Section';
      if (cb && document.getElementById(id)) document.getElementById(id).classList.toggle('open', cb.checked);
    });
  }

