'use strict';
/* Pure dice notation parser; shared by the editor and unit tests.
   Supports NdM +/- NdM +/- integer. No randomness or eval is involved. */
(function(root,factory){
  const api=factory();
  if(typeof module==='object' && module.exports)module.exports=api;
  if(root)root.ForgeDice=api;
})(typeof globalThis!=='undefined'?globalThis:null,function(){
  const PATTERN=/\b\d{1,3}\s*[dD]\s*\d{1,4}(?:\s*[+−-]\s*(?:\d{1,3}\s*[dD]\s*\d{1,4}|\d{1,5}))*/g;
  function average(expression){
    if(typeof expression!=='string')return null;
    const clean=expression.replace(/\s+/g,'').replace(/−/g,'-');
    const terms=clean.match(/^[1-9]\d{0,2}[dD][1-9]\d{0,3}(?:[+-](?:[1-9]\d{0,2}[dD][1-9]\d{0,3}|\d{1,5}))*$/);
    if(!terms)return null;
    const tokens=clean.match(/[+-]?[^+-]+/g)||[];
    let total=0,hasDice=false;
    for(const token of tokens){
      const sign=token.startsWith('-')?-1:1;
      const term=token.replace(/^[+-]/,'');
      if(/[dD]/.test(term)){
        const [count,sides]=term.toLowerCase().split('d').map(Number);
        if(count<1||count>200||sides<2||sides>1000)return null;
        hasDice=true;total+=sign*count*(sides+1)/2;
      }else total+=sign*Number(term);
    }
    return hasDice && Number.isFinite(total)?total:null;
  }
  function format(value){return Number.isInteger(value)?String(value):value.toFixed(1).replace(/\.0$/,'');}
  function matches(text){
    const found=[];if(typeof text!=='string')return found;
    for(const match of text.matchAll(PATTERN)){
      const expression=match[0];const value=average(expression);
      if(value===null)continue;
      const end=match.index+expression.length;
      // Do not double-annotate rolls with explicit user-entered averages immediately after them.
      const after=text.slice(end);
      if(/^\s*\(\s*(?:avg\.?\s*)?-?\d+(?:\.\d+)?\s*(?:avg\.?)?\s*\)/i.test(after))continue;
      // A hit point line such as '22 (4d8 + 4)' already provides its average.
      const priorAverage=/(-?\d+(?:\.\d+)?)\s*\(\s*$/.exec(text.slice(0,match.index));
      if(priorAverage && /^\s*\)/.test(after))continue;
      found.push({expression,value,start:match.index,end});
    }
    return found;
  }
  function decorate(root){
    if(!root || !root.ownerDocument)return;
    const doc=root.ownerDocument;
    const walker=doc.createTreeWalker(root,NodeFilter.SHOW_TEXT,{acceptNode(node){
      if(!node.parentElement || node.parentElement.closest('.dice-average,script,style,textarea'))return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    }});
    const pending=[];while(walker.nextNode())pending.push(walker.currentNode);
    for(const node of pending){
      const found=matches(node.nodeValue);if(!found.length)continue;
      const fragment=doc.createDocumentFragment();let cursor=0;
      for(const roll of found){
        fragment.appendChild(doc.createTextNode(node.nodeValue.slice(cursor,roll.end)));
        const span=doc.createElement('span');span.className='dice-average';span.title='Mathematical mean, not a rolled result';
        span.textContent=` (${format(roll.value)} avg)`;fragment.appendChild(span);cursor=roll.end;
      }
      fragment.appendChild(doc.createTextNode(node.nodeValue.slice(cursor)));
      node.replaceWith(fragment);
    }
  }
  return Object.freeze({average,matches,format,decorate});
});
