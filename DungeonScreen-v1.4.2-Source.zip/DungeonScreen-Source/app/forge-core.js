  // ========== GLOBALS ==========
  let currentMode = 'creature';
  let images = { c: null, i: null };
  let counters = { c_traits:0, c_actions:0, c_bonus:0, c_reactions:0, c_legendary:0, c_lair:0, i_effects:0, i_spells:0 };
  const spellLevelNames = ['Cantrips','1st Level','2nd Level','3rd Level','4th Level','5th Level','6th Level','7th Level','8th Level','9th Level'];
  const weaponProperties = ['Ammunition','Finesse','Heavy','Light','Loading','Reach','Thrown','Two-Handed','Versatile','Special'];
  const rarityColors = { common:'#6b6b6b', uncommon:'#2e7d32', rare:'#1565c0', veryrare:'#6a1b9a', legendary:'#e65100', artifact:'#b71c1c' };
  const rarityLabels = { common:'Common', uncommon:'Uncommon', rare:'Rare', veryrare:'Very Rare', legendary:'Legendary', artifact:'Artifact' };
  const typeLabels = { weapon:'Weapon', armor:'Armor', shield:'Shield', ring:'Ring', amulet:'Wondrous Item (Amulet)', wand:'Wand', staff:'Staff', rod:'Rod', potion:'Potion', scroll:'Scroll', wondrous:'Wondrous Item', custom:'Item' };

  // ========== HELPERS ==========
  const esc = value => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const v = id => esc(document.getElementById(id).value.trim());
  const score = id => { const x = Number.parseInt(document.getElementById(id).value, 10); return Number.isFinite(x) ? x : 10; };
  const n = id => parseInt(document.getElementById(id).value) || 0;
  function mod(s) { const m = Math.floor((s-10)/2); return m>=0?`+${m}`:`${m}`; }
  function ordinal(n) { const s=['th','st','nd','rd']; const v=n%100; return n+(s[(v-20)%10]||s[v]||s[0]); }
  function togSec(id, cb) { document.getElementById(id).classList.toggle('open', cb.checked); }

  // ========== MODE TOGGLE ==========
  function setMode(mode) {
    currentMode = mode;
    document.getElementById('modeCreature').classList.toggle('active', mode==='creature');
    document.getElementById('modeItem').classList.toggle('active', mode==='item');
    document.getElementById('creatureEditor').style.display = mode==='creature'?'block':'none';
    document.getElementById('itemEditor').style.display = mode==='item'?'block':'none';
    // Reset preview
    document.getElementById('outputContainer').style.display = 'none';
    document.getElementById('exportBar').style.display = 'none';
    document.getElementById('previewPlaceholder').style.display = 'flex';
  }

  // ========== IMAGE HANDLING ==========
  ['c','i'].forEach(prefix => {
    document.getElementById(prefix+'_imageInput').addEventListener('change', function(e) {
      const file = e.target.files[0]; if (!file) return;
      const reader = new FileReader();
      reader.onload = ev => {
        images[prefix] = ev.target.result;
        document.getElementById(prefix+'_imagePreview').src = images[prefix];
        document.getElementById(prefix+'_imagePreview').style.display = 'block';
        document.getElementById(prefix+'_imgPlaceholder').style.display = 'none';
        document.getElementById(prefix+'_clearImgBtn').style.display = 'inline-block';
        window.forgeImageChanged?.(prefix);
      };
      reader.readAsDataURL(file);
    });
  });
  function clearImg(prefix) {
    images[prefix] = null;
    document.getElementById(prefix+'_imagePreview').style.display = 'none';
    document.getElementById(prefix+'_imgPlaceholder').style.display = 'block';
    document.getElementById(prefix+'_clearImgBtn').style.display = 'none';
    document.getElementById(prefix+'_imageInput').value = '';
    window.forgeImageChanged?.(prefix);
  }

  // ========== CREATURE: Spell levels ==========
  const slContainer = document.getElementById('c_spellLevelsContainer');
  spellLevelNames.forEach((name, i) => {
    const isCantrip = i===0;
    const row = document.createElement('div');
    row.className = 'spell-level-row'; row.id = `c_spellRow_${i}`;
    row.innerHTML = `<div class="sl-toggle"><input type="checkbox" id="c_spellToggle_${i}" onchange="document.getElementById('c_spellRow_${i}').classList.toggle('active',this.checked)"></div>
      <div class="sl-label">${name}</div>
      <div class="sl-fields">${!isCantrip?`<div class="sl-slots-row"><label>Slots:</label><input type="number" id="c_spellSlots_${i}" value="${Math.max(1,5-Math.floor(i/2))}" min="0" max="9"></div>`:''}<textarea id="c_spellList_${i}" placeholder="${isCantrip?'e.g. Fire Bolt, Mage Hand':'Spell names, comma separated'}"></textarea></div>`;
    slContainer.appendChild(row);
  });

  // ========== ITEM: Weapon property chips ==========
  const wpGrid = document.getElementById('i_weaponProps');
  weaponProperties.forEach((p,i) => {
    const chip = document.createElement('div'); chip.className = 'prop-chip';
    chip.innerHTML = `<input type="checkbox" id="i_wprop_${i}"><label for="i_wprop_${i}">${p}</label>`;
    // The associated label already toggles this checkbox; an extra click handler toggled it twice.
    wpGrid.appendChild(chip);
  });

  // ========== ITEM: Type change ==========
  function onItemTypeChange() {
    const type = v('i_type');
    ['i_weaponFields','i_armorFields','i_shieldFields','i_consumableFields'].forEach(p => document.getElementById(p).classList.remove('open'));
    if (type==='weapon'||type==='staff') document.getElementById('i_weaponFields').classList.add('open');
    if (type==='armor') document.getElementById('i_armorFields').classList.add('open');
    if (type==='shield') document.getElementById('i_shieldFields').classList.add('open');
    if (type==='potion'||type==='scroll') document.getElementById('i_consumableFields').classList.add('open');
  }
  onItemTypeChange();

  // ========== DYNAMIC ENTRIES (CREATURE) ==========
  function addEntry(type) {
    const contId = type + 'Container';
    const container = document.getElementById(contId);
    const id = counters[type]++;
    const isLegendary = type==='c_legendary';
    const isLair = type==='c_lair';
    const costField = isLegendary ? `<div class="field-group tiny"><label>Cost</label><input type="text" id="${type}_cost_${id}" placeholder="1"></div>` : '';
    const block = document.createElement('div'); block.className = 'entry-block';
    block.innerHTML = `<button class="remove-btn" onclick="this.parentElement.remove()">✕</button>
      <div class="field-row"><div class="field-group"><label>Name</label><input type="text" id="${type}_name_${id}" placeholder="${isLair?'e.g. Tremor':'e.g. Bite'}"></div>${costField}</div>
      <div class="field-row"><div class="field-group full"><label>Description</label><textarea id="${type}_desc_${id}" placeholder="Describe..."></textarea></div></div>`;
    container.appendChild(block);
  }

  function collectEntries(type) {
    const blocks = document.getElementById(type+'Container').querySelectorAll('.entry-block');
    const entries = [];
    blocks.forEach(block => {
      const nameEl = block.querySelector(`[id^="${type}_name_"]`);
      if (nameEl && nameEl.value.trim()) {
        const descEl = block.querySelector(`[id^="${type}_desc_"]`);
        const costEl = block.querySelector(`[id^="${type}_cost_"]`);
        entries.push({ name:nameEl.value.trim(), desc:descEl?descEl.value.trim():'', cost:costEl?costEl.value.trim():'' });
      }
    });
    return entries;
  }

  // ========== DYNAMIC ENTRIES (ITEM) ==========
  function addItemEffect() {
    const container = document.getElementById('i_effectsContainer');
    const id = counters.i_effects++;
    const block = document.createElement('div'); block.className = 'entry-block';
    block.innerHTML = `<button class="remove-btn" onclick="this.parentElement.remove()">✕</button>
      <div class="field-row"><div class="field-group"><label>Effect Name</label><input type="text" id="i_eff_name_${id}" placeholder="e.g. Flame Tongue"></div><div class="field-group tiny"><label>Charge Cost</label><input type="number" id="i_eff_cost_${id}" placeholder="0" min="0"></div></div>
      <div class="field-row"><div class="field-group full"><label>Description</label><textarea id="i_eff_desc_${id}" placeholder="Describe the effect..."></textarea></div></div>`;
    container.appendChild(block);
  }
  function addItemSpell() {
    const container = document.getElementById('i_spellsContainer');
    const id = counters.i_spells++;
    const block = document.createElement('div'); block.className = 'entry-block';
    block.innerHTML = `<button class="remove-btn" onclick="this.parentElement.remove()">✕</button>
      <div class="field-row"><div class="field-group"><label>Spell Name</label><input type="text" id="i_spell_name_${id}" placeholder="e.g. Fireball"></div><div class="field-group tiny"><label>Charges</label><input type="number" id="i_spell_cost_${id}" value="1" min="0"></div><div class="field-group small"><label>Spell Level</label><input type="text" id="i_spell_level_${id}" placeholder="3rd"></div></div>`;
    container.appendChild(block);
  }
  function collectItemEntries(containerId, prefix) {
    const blocks = document.getElementById(containerId).querySelectorAll('.entry-block');
    const items = [];
    blocks.forEach(block => {
      const name = block.querySelector(`[id^="${prefix}_name_"]`);
      if (name && name.value.trim()) {
        const item = { name:name.value.trim() };
        const desc = block.querySelector(`[id^="${prefix}_desc_"]`);
        const cost = block.querySelector(`[id^="${prefix}_cost_"]`);
        const level = block.querySelector(`[id^="${prefix}_level_"]`);
        if (desc) item.desc = desc.value.trim();
        if (cost) item.cost = cost.value.trim();
        if (level) item.level = level.value.trim();
        items.push(item);
      }
    });
    return items;
  }

  // ========== SHOW OUTPUT ==========
  function showOutput(html) {
    const output = document.getElementById('outputContainer');
    output.innerHTML = html;
    output.style.display = 'block';
    document.getElementById('previewPlaceholder').style.display = 'none';
    document.getElementById('exportBar').style.display = 'flex';
  }

  // ========== GENERATE CREATURE ==========
  function generateCreature() {
    const $ = id => document.getElementById(id);
    const name=v('c_name')||'Unnamed Creature';
    const size=v('c_size'), type=v('c_type')||'Unknown', alignment=v('c_alignment')||'Unaligned';
    const abilities=['str','dex','con','int','wis','cha'].map(a=>score('c_'+a));
    const traits=collectEntries('c_traits'), actions=collectEntries('c_actions'), bonus=collectEntries('c_bonus');
    const reactions=collectEntries('c_reactions'), legendary=collectEntries('c_legendary'), lair=collectEntries('c_lair');
    const hasLeg=$('c_legendaryToggle').checked && legendary.length>0;
    const hasLair=$('c_lairToggle').checked && lair.length>0;
    const legCount=n('c_legendaryCount')||3;
    function prop(label, val, cls='') {return val?`<div class="sb-property ${cls}"><strong>${label}</strong><span>${val}</span></div>`:'';}
    function renderE(entries,kind='normal') {
      return entries.map(e=>{
        const c=kind==='legendary' && e.cost && e.cost!=='1'?` (Costs ${esc(e.cost)} Actions)`:'';
        return `<div class="sb-trait"><em>${esc(e.name)}${c}.</em> ${esc(e.desc)}</div>`;
      }).join('');
    }
    function section(title,content,extra='') {return content?`<section class="sb-section ${extra}"><div class="sb-section-title">${title}</div>${content}</section>`:'';}
    const hero=images.c?`<img class="sb-creature-image" src="${images.c}" alt="Creature artwork">`:'';
    let h=`<div class="sb-content"><div class="sb-heading">${hero}<div class="sb-heading-text"><div class="sb-kicker">CREATURE · FIFTH EDITION</div><div class="sb-name">${name}</div><div class="sb-subtitle">${size} ${type}, ${alignment}</div>`;
    const desc=v('c_description');if(desc)h+=`<div class="sb-description">${desc}</div>`;
    h+=`</div></div><div class="sb-summary">`;
    h+=prop('Armor Class',v('c_ac'),'sb-important');
    h+=prop('Hit Points',v('c_hp'),'sb-important');
    h+=prop('Speed',v('c_speed'),'sb-important');
    h+=`</div><div class="sb-stats">`;
    h+=['STR','DEX','CON','INT','WIS','CHA'].map(x=>`<div class="stat-head">${x}</div>`).join('');
    h+=abilities.map(x=>`<div class="stat-val">${x} <span>(${mod(x)})</span></div>`).join('');
    h+=`</div>`;
    let details='';
    for(const [label,id] of [
      ['Saving Throws','c_saves'],['Skills','c_skills'],['Damage Vulnerabilities','c_vulns'],
      ['Damage Resistances','c_resists'],['Damage Immunities','c_immunes'],
      ['Condition Immunities','c_condImmunes'],['Senses','c_senses'],
      ['Languages','c_languages'],['Challenge','c_cr'],['Proficiency Bonus','c_prof']
    ])details+=prop(label,v(id));
    if(details)h+=`<div class="sb-details">${details}</div>`;
    let content='';
    content+=section('Traits',renderE(traits));
    if($('c_spellcastingToggle').checked){
      const ability=v('c_spellAbility'),dc=v('c_spellDC'),atk=v('c_spellAtk'),lvl=n('c_spellLevel')||1;
      let spellLines='';
      for(let i=0;i<10;i++){
        if(!$(`c_spellToggle_${i}`).checked)continue;
        const spells=v(`c_spellList_${i}`);if(!spells)continue;
        if(i===0)spellLines+=`<div class="sb-spell-level"><strong>Cantrips (at will)</strong> ${spells}</div>`;
        else{const slots=$(`c_spellSlots_${i}`).value||'0';spellLines+=`<div class="sb-spell-level"><strong>${spellLevelNames[i]} (${slots} slot${slots==='1'?'':'s'})</strong> ${spells}</div>`;}
      }
      if(spellLines){
        const intro=`<div class="sb-legendary-preamble">${name} is a ${ordinal(lvl)}-level spellcaster. Its spellcasting ability is ${ability} (spell save DC ${dc}${atk?`, ${atk} to hit with spell attacks`:''}).</div>`;
        content+=section('Spellcasting',intro+spellLines);
      }
    }
    content+=section('Actions',renderE(actions));
    content+=section('Bonus Actions',renderE(bonus));
    content+=section('Reactions',renderE(reactions));
    if(hasLeg){
      const intro=`<div class="sb-legendary-preamble">${name} can take ${legCount} legendary action${legCount>1?'s':''}, choosing from the options below. Only one option can be used at a time and only at the end of another creature's turn. ${name} regains spent legendary actions at the start of its turn.</div>`;
      content+=section('Legendary Actions',intro+renderE(legendary,'legendary'));
    }
    if(hasLair){
      const intro=`<div class="sb-legendary-preamble">On initiative count 20 (losing initiative ties), ${name} can take a lair action to cause one of the following effects:</div>`;
      content+=section('Lair Actions',intro+renderE(lair));
    }
    h+=`<div class="sb-body">${content}</div></div>`;
    showOutput(`<div class="stat-block" id="exportTarget">${h}</div>`);
  }

  // ========== GENERATE ITEM ==========
  function generateItem() {
    const name=v('i_name')||'Unnamed Item', type=v('i_type'), rarity=v('i_rarity');
    const rc=rarityColors[rarity], rn=rarityLabels[rarity];
    const customLabel=v('i_customLabel'), typeName=customLabel||typeLabels[type]||'Item';
    const lore=v('i_lore');
    const hasAtt=document.getElementById('i_attunementToggle').checked;
    const attReq=v('i_attunementReq');
    let attStr=''; if (hasAtt) attStr=attReq?`(requires attunement ${attReq})`:'(requires attunement)';

    let h = `<div class="ic-border-top"></div><div class="ic-rarity-bar" style="background:${rc};"></div>`;
    if (images.i) h += `<img class="ic-image" src="${images.i}" alt="${name}">`;
    h += `<div class="ic-content">`;
    h += `<div class="ic-name">${name}</div><div class="ic-subtitle">${typeName} ${attStr}</div>`;
    h += `<div class="ic-rarity-text" style="color:${rc};">${rn}</div>`;
    if (lore) h += `<div class="ic-description">${lore}</div>`;
    h += `<hr class="ic-divider">`;

    // Weapon
    if ((type==='weapon'||type==='staff')&&document.getElementById('i_weaponFields').classList.contains('open')) {
      const base=v('i_baseWeapon'), cat=v('i_weaponCat'), dmg=v('i_weaponDmg'), dt=v('i_dmgType'), bonus=v('i_weaponBonus'), range=v('i_weaponRange');
      if (base) h += `<div class="ic-prop"><strong>Weapon:</strong> ${base} (${cat})</div>`;
      if (dmg) h += `<div class="ic-prop"><strong>Base Damage:</strong> ${dmg} ${dt.toLowerCase()}</div>`;
      if (bonus) h += `<div class="ic-prop"><strong>Magic Bonus:</strong> ${bonus} to attack and damage rolls</div>`;
      if (range) h += `<div class="ic-prop"><strong>Range:</strong> ${range}</div>`;
      const activeP=[]; weaponProperties.forEach((p,i)=>{ if(document.getElementById(`i_wprop_${i}`).checked) activeP.push(p); });
      if (activeP.length) h += `<div class="ic-prop"><strong>Properties:</strong> ${activeP.join(', ')}</div>`;
    }
    // Armor
    if (type==='armor') {
      const base=v('i_baseArmor'),ac=v('i_armorAC'),bonus=v('i_armorBonus'),str=v('i_armorStr'),stealth=document.getElementById('i_stealthDisadv').checked,at=v('i_armorType');
      if (base) h += `<div class="ic-prop"><strong>Armor:</strong> ${base} (${at})</div>`;
      h += `<div class="ic-prop"><strong>Armor Class:</strong> ${ac}${bonus?' '+bonus:''}</div>`;
      if (str) h += `<div class="ic-prop"><strong>Strength Required:</strong> ${str}</div>`;
      if (stealth) h += `<div class="ic-prop"><strong>Stealth:</strong> Disadvantage on Dexterity (Stealth) checks</div>`;
    }
    // Shield
    if (type==='shield') { const ac=v('i_shieldAC'),bonus=v('i_shieldBonus'); h += `<div class="ic-prop"><strong>AC Bonus:</strong> ${ac}${bonus?' plus '+bonus+' magical bonus':''}</div>`; }
    // Consumable
    if (type==='potion'||type==='scroll') { const eff=v('i_consumableEffect'),dur=v('i_consumableDur'); if(eff) h+=`<div class="ic-prop">${eff}</div>`; if(dur) h+=`<div class="ic-prop"><strong>Duration:</strong> ${dur}</div>`; }

    // Effects
    const effects = collectItemEntries('i_effectsContainer','i_eff');
    if (effects.length) {
      h += `<div class="ic-section-title">Magical Properties</div>`;
      effects.forEach(e => { const c=e.cost&&e.cost!=='0'?` (${esc(e.cost)} charge${e.cost!=='1'?'s':''})`:''; h += `<div class="ic-effect"><em>${esc(e.name)}${c}.</em> ${esc(e.desc||'')}</div>`; });
    }
    // Item Spells
    const spells = collectItemEntries('i_spellsContainer','i_spell');
    if (document.getElementById('i_spellsToggle').checked && spells.length) {
      h += `<div class="ic-section-title">Spells</div>`;
      h += `<div class="ic-effect">The item allows the user to cast the following spells (see each spell's listed charge cost):</div>`;
      spells.forEach(s => { const c=s.cost?`${esc(s.cost)} charge${s.cost!=='1'?'s':''}`:''; const l=s.level?` (${esc(s.level)} level)`:''; h += `<div class="ic-effect">• <em>${esc(s.name)}</em>${l}${c?' — '+c:''}</div>`; });
    }
    // Charges
    if (document.getElementById('i_chargesToggle').checked) {
      const mc=v('i_maxCharges'),ra=v('i_regainAmt'),rt=v('i_regainTime');
      const rl={dawn:'at dawn',dusk:'at dusk',short:'after a short rest',long:'after a long rest',never:''};
      h += `<hr class="ic-divider">`;
      let cs = `<strong>Charges.</strong> This item has ${mc} charges.`;
      if(rt==='dawn' || rt==='dusk') {
        if(ra)cs+=` The item regains ${ra} expended charge${ra==='1'?'':'s'} daily ${rl[rt]}.`;
      }else if((rt==='short'||rt==='long')&&ra) {
        cs+=` The item regains ${ra} expended charge${ra==='1'?'':'s'} when you finish a ${rt} rest.`;
      }else if(rt==='never'){
        cs+=` Expended charges do not replenish.`;
      }
      if (document.getElementById('i_destroyOnZero').checked) { const dt=v('i_destroyThreshold'); if(dt) cs += ` If you expend the item's last charge, ${dt}.`; }
      h += `<div class="ic-charges">${cs}</div>`;
    }
    // Curse
    if (document.getElementById('i_curseToggle').checked) { const cd=v('i_curseDesc'); if(cd) { h+=`<div class="ic-section-title" style="color:#6b1a1a;border-color:#6b1a1a;">Curse</div><div class="ic-curse">${cd}</div>`; } }
    // Sentient
    if (document.getElementById('i_sentientToggle').checked) {
      h += `<div class="ic-section-title">Sentience</div>`;
      const sa=v('i_sentientAlign'),sc=v('i_sentientComm'),si=v('i_sentientInt'),sw=v('i_sentientWis'),sch=v('i_sentientCha'),ss=v('i_sentientSenses'),sl=v('i_sentientLangs'),sp=v('i_sentientPersonality');
      let st = `${name} is a sentient ${sa||''} item with Intelligence ${si}, Wisdom ${sw}, and Charisma ${sch}.`;
      if(ss) st+=` It has ${ss.toLowerCase()}.`; if(sl) st+=` It speaks ${sl}.`; st+=` It communicates via ${sc.toLowerCase()}.`;
      h += `<div class="ic-sentient">${st}</div>`;
      if(sp) h += `<div class="ic-sentient" style="margin-top:0.3rem;">${sp}</div>`;
    }
    h += `</div><div class="ic-rarity-bar" style="background:${rc};"></div><div class="ic-border-bot"></div>`;
    showOutput(`<div class="item-card" id="exportTarget">${h}</div>`);
  }
