"""Add Windows Explorer VERSIONINFO to a compiled, unsigned PE32+ executable.
No external PE utilities needed. Used only for reproducible local builds.
"""
from __future__ import annotations
import sys, struct, pathlib

ALIGN=lambda x,n:(x+n-1)//n*n
U16=lambda s:s.encode('utf-16le')+b'\0\0'

def record(key:str, value:bytes=b'', typ:int=1, children:tuple[bytes,...]=(), value_length:int|None=None):
    res=bytearray(b'\0'*6+U16(key))
    res.extend(b'\0'*(ALIGN(len(res),4)-len(res)))
    res.extend(value)
    if children and len(value):res.extend(b'\0'*(ALIGN(len(res),4)-len(res)))
    for child in children:
        res.extend(b'\0'*(ALIGN(len(res),4)-len(res)))
        res.extend(child)
    if value_length is None:value_length=len(value)//2 if typ==1 else len(value)
    struct.pack_into('<HHH',res,0,len(res),value_length,typ)
    return bytes(res)

def make_version():
    fields={
      'CompanyName':'Darkpilot',
      'FileDescription':'DungeonScreen',
      'FileVersion':'1.4.2',
      'InternalName':'DungeonScreen',
      'OriginalFilename':'DungeonScreen.exe',
      'ProductName':'DungeonScreen',
      'ProductVersion':'1.4.2',
    }
    children=tuple(record(k,U16(v)) for k,v in fields.items())
    table=record('040904E4',children=children)
    stringinfo=record('StringFileInfo',children=(table,))
    translation=record('Translation',struct.pack('<HH',0x0409,0x04e4),typ=0)
    varinfo=record('VarFileInfo',children=(translation,))
    fixed=struct.pack('<13I',0xFEEF04BD,0x10000,(1<<16)|4,(2<<16)|0,(1<<16)|4,(2<<16)|0,0x3F,0,0x40004,1,0,0,0)
    return record('VS_VERSION_INFO',fixed,typ=0,children=(stringinfo,varinfo),value_length=len(fixed))

def checksum(buf,offset):
    b=bytearray(buf)
    struct.pack_into('<I',b,offset,0)
    size=len(b)
    if size&1:b.append(0)
    total=0
    for i in range(0,len(b),2):
        total+=b[i]+(b[i+1]<<8)
        total=(total&0xffff)+(total>>16)
    total=(total&0xffff)+(total>>16)
    return (total+size)&0xffffffff

def patch(inputfile):
    path=pathlib.Path(inputfile)
    b=bytearray(path.read_bytes())
    if b[:2]!=b'MZ':raise ValueError('Not a PE executable')
    pe=struct.unpack_from('<I',b,0x3c)[0]
    assert b[pe:pe+4]==b'PE\0\0'
    n=struct.unpack_from('<H',b,pe+6)[0]
    opt=pe+24
    assert struct.unpack_from('<H',b,opt)[0]==0x20b,'Only PE32+ supported'
    opSize=struct.unpack_from('<H',b,pe+20)[0]
    sect=opt+opSize
    rawFirst=struct.unpack_from('<I',b,sect+20)[0]
    if sect+40*(n+1)>rawFirst:raise ValueError('Insufficient section header space')
    secAlign,fileAlign=struct.unpack_from('<II',b,opt+32)
    last=sect+(n-1)*40
    lastVA=struct.unpack_from('<I',b,last+12)[0]
    lastVS=struct.unpack_from('<I',b,last+8)[0]
    va=ALIGN(lastVA+lastVS,secAlign)
    version=make_version()
    dataoffset=88
    resources=bytearray(dataoffset)
    # Three-level RT_VERSION / ID 1 / English (United States) resource tree.
    for off in (0,24,48):struct.pack_into('<IIHHHH',resources,off,0,0,0,0,0,1)
    struct.pack_into('<II',resources,16,16,0x80000000|24)
    struct.pack_into('<II',resources,40,1,0x80000000|48)
    struct.pack_into('<II',resources,64,0x409,72)
    struct.pack_into('<IIII',resources,72,va+dataoffset,len(version),1252,0)
    resources+=version
    rsize=len(resources)
    rawStart=ALIGN(len(b),fileAlign)
    b.extend(bytes(rawStart-len(b)))
    b.extend(resources)
    b.extend(bytes(ALIGN(len(resources),fileAlign)-len(resources)))
    numSecPos=pe+6
    struct.pack_into('<H',b,numSecPos,n+1)
    newHdr=sect+40*n
    struct.pack_into('<8sIIIIIIHHI',b,newHdr,b'.rsrc\0\0\0',rsize,va,ALIGN(rsize,fileAlign),rawStart,0,0,0,0,0x40000040)
    # SizeOfImage; SizeOfInitializedData; IMAGE_DIRECTORY_ENTRY_RESOURCE
    struct.pack_into('<I',b,opt+56,ALIGN(va+rsize,secAlign))
    struct.pack_into('<I',b,opt+8,struct.unpack_from('<I',b,opt+8)[0]+ALIGN(rsize,fileAlign))
    struct.pack_into('<II',b,opt+112+8*2,va,rsize)
    struct.pack_into('<I',b,opt+64,checksum(b,opt+64))
    path.write_bytes(b)
    print('Patched',path,'section RVA',hex(va),'VERSIONINFO bytes',len(version),'file size',len(b))

if __name__=='__main__':patch(sys.argv[1])
