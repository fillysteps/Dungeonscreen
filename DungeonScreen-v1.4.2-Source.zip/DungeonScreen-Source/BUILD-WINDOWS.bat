@echo off
setlocal
cd /d "%~dp0"
where go >nul 2>nul
if errorlevel 1 (
  echo Go 1.22 or newer is required to compile from source.
  echo A precompiled DungeonScreen.exe is available separately; no Go is needed to use it.
  pause
  exit /b 1
)
set GOOS=windows
set GOARCH=amd64
set CGO_ENABLED=0
go build -trimpath -ldflags="-s -w -H windowsgui -X main.buildVersion=1.4.2" -o DungeonScreen.exe .
if errorlevel 1 (
  echo Build failed.
  pause
  exit /b 1
)
where python >nul 2>nul
if not errorlevel 1 python windows_metadata.py DungeonScreen.exe
echo DungeonScreen.exe compiled. The build is unsigned.
pause
