# DungeonScreen 1.4.2 — Library navigation patch

This maintenance release corrects four usability issues identified in the v1.4.1 QA audit. It does not change the Campaign or entry storage format.

- **Library search and tags:** Matching entries in closed folders are temporarily revealed along their folder paths. Clearing a search restores the original expanded/collapsed state. Wide Project Manager layouts show a dedicated results column.
- **Locate Original:** Project references now navigate to the canonical entry by stable ID, open its folder ancestry, and highlight it, including in the wide-column layout.
- **Editor Ctrl+F:** Search results inside collapsed optional sections are revealed before the matching field is highlighted. Search does not enable the optional feature in saved data.
- **Load submenu:** A dedicated search box accesses every entry of the current entry type. For performance, the menu displays the first 60 matches and prompts users to narrow the search when necessary. The five most recent revisions remain available.

Testing in a headless browser is not equivalent to executing the Windows build or Android APK on physical devices. Native PNG/PDF export and detached-window behavior still require platform-specific verification.

# DungeonScreen 1.4.1 — Inline Projects correction

This maintenance release changes the Project Manager interface, without changing the Campaign file format.

- Removed the large Entries/Projects mode switch. Projects are now a collapsible section at the top of the entry library.
- The small **+** icon expands Projects in place; **−** collapses it to recently opened Projects. Each control has its own hover label.
- Opening a Project displays its references and folders inline in the manager. The original entry categories stay available below it. When Editor and Preview are detached, selecting a Project displays its contents in the adjacent column without replacing the library.
- Added separate Project sorting and sort direction; entry sorting remains independent.
- Rounded entry and folder rows and added a semi-transparent rounded drag image, retaining existing drop-zone behavior.
- Updated About guidance and Android source to match the corrected layout.

Compatibility: Existing Campaigns, entry IDs, Project references, and `dungeonscreen.library.json` are unchanged. No migration is required. Back up important Campaign folders before upgrading.

Verification: Chromium interaction tests covered inline expansion, collapse, linked entry display, separate sort preferences, rounded/transparent dragging, and detached-panel column layout. The Windows executable is cross-compiled but not executed on Windows; Android source is not compiled into an APK in this environment.
