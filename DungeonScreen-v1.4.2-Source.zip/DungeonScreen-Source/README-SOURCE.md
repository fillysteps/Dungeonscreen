# DungeonScreen 1.4 — Windows source

DungeonScreen is an offline-first D&D 5e (2014) editor and organizer built with Go's standard library and a local HTML/JavaScript interface. The compiled Windows edition runs from a single executable and uses installed Edge or Chrome to display the workspace.

For an overview, see [README.md](README.md). Release notes are in [CHANGELOG.md](CHANGELOG.md).

## Build from source

Install Go 1.22 or later and run `BUILD-WINDOWS.bat` on Windows. The script builds `DungeonScreen.exe` and uses Python 3, if available, to add product/version metadata. Python is not needed to use the application.

Alternatively, from any system with Go:

```bash
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags='-s -w -H windowsgui -X main.buildVersion=1.4.2' -o DungeonScreen.exe .
```

Use `python3 windows_metadata.py DungeonScreen.exe` after cross-compiling if you want the Windows Explorer metadata. This is **not** code signing.

For local development on Linux or macOS, run `go run .`. The application serves its embedded interface locally on a loopback address; it is not intended for remote hosting.

## Data format

`forge.project.json` is the historical Campaign manifest, maintained for Forge compatibility. Canonical entries are JSON files within typed folders (`Creatures`, `Magic Items`, `Characters`, and so on). `dungeonscreen.library.json` stores optional organizer metadata: virtual folders, Projects, labels, colors, tag lists, and references by entry type and immutable ID.

Opening an older Campaign does not require destructive migration. The additional metadata is created when organizational changes are made. Back up Campaigns before version changes.

## Verification

`go test ./...` and `node --check app/dungeon.js` were run. Browser integration tests covered saving/reopening a Character Sheet, linked inventory data, Project metadata, and About documentation. The Go service read a Campaign exported from a simulated mobile file provider. A Windows binary was cross-compiled and checked as PE32+; it was not executed on Windows in this environment. Native window synchronization and export behavior require device testing.
