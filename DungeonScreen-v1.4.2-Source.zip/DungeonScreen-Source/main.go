// DungeonScreen portable local application. No Electron, npm, or external Go dependencies.
package main

import (
	"crypto/rand"
	"crypto/sha1"
	"embed"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"log"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

//go:embed app/*
var webFiles embed.FS
var buildVersion = "1.4.2"
var folders = map[string]string{"creature": "Creatures", "item": "Magic Items", "encounter": "Encounters", "quest": "Quests", "note": "Notes", "spell": "Spells", "character": "Characters"}
var idPat = regexp.MustCompile(`^[0-9a-f]{16}$`)
var refPat = regexp.MustCompile(`^Artwork/[a-f0-9]{40}\.(png|jpg|jpeg|webp|gif)$`)
var revisionPat = regexp.MustCompile(`^\d{8}T\d{6}-[0-9a-f]{8}\.json$`)
var invalidName = regexp.MustCompile(`[\\/\x00-\x1f<>:"|?*]`)
var appMu sync.Mutex
var liveSessions atomic.Int32
var everConnected atomic.Bool
var lastDisconnect atomic.Int64
var activeProject string
var configPath string
var portableFolder string
var appSettings Settings

type Settings struct {
	Recent         []string `json:"recent"`
	LastProject    string   `json:"lastProject"`
	DefaultRoot    string   `json:"defaultRoot"`
	Storage        string   `json:"storage"`
	Browser        string   `json:"browser"`
	Sort           string   `json:"sort"`
	ProjectSort    string   `json:"projectSort"`
	ProjectReverse bool     `json:"projectSortDescending"`
	UiTheme        string   `json:"uiTheme"`
	UIBase         string   `json:"uiBase"`
	UIPrimary      string   `json:"uiPrimary"`
	UIAccent       string   `json:"uiAccent"`
	UIScale        float64  `json:"uiScale"`
	TextScale      float64  `json:"textScale"`
	PreviewTheme   string   `json:"previewTheme"`
	PreviewPrimary string   `json:"previewPrimary"`
	PreviewAccent  string   `json:"previewAccent"`
	ShowThumbs     *bool    `json:"showThumbs"`
	DefaultFont    string   `json:"defaultFont"`
	ManagerFont    string   `json:"managerFont"`
	EditorFont     string   `json:"editorFont"`
	PreviewFont    string   `json:"previewFont"`
	SortDescending bool     `json:"sortDescending"`
}
type Document struct {
	SchemaVersion int            `json:"schemaVersion"`
	ID            string         `json:"id"`
	Type          string         `json:"type"`
	Name          string         `json:"name"`
	CreatedAt     string         `json:"createdAt"`
	UpdatedAt     string         `json:"updatedAt"`
	Artwork       string         `json:"artwork,omitempty"`
	State         map[string]any `json:"state"`
	ImageData     string         `json:"imageData,omitempty"`
	Color         string         `json:"color,omitempty"`
}
type Request struct {
	Action    string          `json:"action"`
	Name      string          `json:"name"`
	Path      string          `json:"path"`
	Type      string          `json:"type"`
	ID        string          `json:"id"`
	Revision  string          `json:"revision"`
	Document  Document        `json:"document"`
	Settings  Settings        `json:"settings"`
	HTML      string          `json:"html"`
	Format    string          `json:"format"`
	Filename  string          `json:"filename"`
	Panel     string          `json:"panel"`
	Library   json.RawMessage `json:"library"`
	ImageData string          `json:"imageData"`
	Width     int             `json:"width"`
	Height    int             `json:"height"`
}

func randomHex(n int) string { b := make([]byte, n); _, _ = rand.Read(b); return hex.EncodeToString(b) }
func userConfigPath() string {
	dir, err := os.UserConfigDir()
	if err != nil {
		dir = os.TempDir()
	}
	return filepath.Join(dir, "DungeonScreen", "settings.json")
}
func homeDir() string {
	h, _ := os.UserHomeDir()
	if h == "" {
		h = "."
	}
	return h
}
func defaultRoot() string { return filepath.Join(homeDir(), "Documents", "DungeonScreen", "Projects") }
func sanitizeSettings(s Settings) Settings {
	if s.Storage != "portable" && s.Storage != "custom" {
		s.Storage = "documents"
	}
	if s.Browser != "default" {
		s.Browser = "app"
	}
	if s.Sort == "" {
		s.Sort = "modified"
	}
	if s.UiTheme == "" {
		s.UiTheme = "midnight"
	}
	if s.UIBase != "parchment" && s.UIBase != "frost" && s.UIBase != "verdant" {
		s.UIBase = "midnight"
	}
	if s.UIPrimary == "" {
		s.UIPrimary = "#8b82bc"
	}
	if s.UIAccent == "" {
		s.UIAccent = "#d4ab70"
	}
	if s.UIScale < .8 || s.UIScale > 1.5 {
		s.UIScale = 1
	}
	if s.TextScale < .8 || s.TextScale > 1.6 {
		s.TextScale = 1
	}
	if s.PreviewTheme == "" {
		s.PreviewTheme = "parchment"
	}
	if s.PreviewPrimary == "" {
		s.PreviewPrimary = "#8b82bc"
	}
	if s.PreviewAccent == "" {
		s.PreviewAccent = "#d4ab70"
	}
	if s.DefaultRoot == "" {
		s.DefaultRoot = defaultRoot()
	}
	if s.Storage == "portable" {
		s.DefaultRoot = filepath.Join(portableFolder, "Projects")
	}
	if s.Storage == "documents" {
		s.DefaultRoot = defaultRoot()
	}
	return s
}
func readSettings(path string) Settings {
	b, e := os.ReadFile(path)
	if e != nil {
		return sanitizeSettings(Settings{})
	}
	var s Settings
	if json.Unmarshal(b, &s) != nil {
		return sanitizeSettings(Settings{})
	}
	return sanitizeSettings(s)
}
func storeSettings() error {
	appSettings = sanitizeSettings(appSettings)
	b, e := json.MarshalIndent(appSettings, "", "  ")
	if e != nil {
		return e
	}
	if e = os.MkdirAll(filepath.Dir(configPath), 0755); e != nil {
		return e
	}
	return atomicWrite(configPath, append(b, '\n'))
}
func atomicWrite(file string, content []byte) error {
	if e := os.MkdirAll(filepath.Dir(file), 0755); e != nil {
		return e
	}
	tmp := file + "." + randomHex(4) + ".tmp"
	if e := os.WriteFile(tmp, content, 0600); e != nil {
		return e
	}
	if e := os.Rename(tmp, file); e != nil {
		os.Remove(tmp)
		return e
	}
	return nil
}
func writeJSON(file string, v any) error {
	b, e := json.MarshalIndent(v, "", "  ")
	if e != nil {
		return e
	}
	return atomicWrite(file, append(b, '\n'))
}
func validName(n string) error {
	if len([]rune(n)) == 0 || len([]rune(n)) > 100 || n == "." || n == ".." || invalidName.MatchString(n) || strings.HasSuffix(n, ".") || strings.HasSuffix(n, " ") {
		return errors.New("Use a 1–100 character name without filename punctuation.")
	}
	return nil
}
func slug(s string) string {
	s = strings.ToLower(s)
	var b strings.Builder
	hyphen := false
	for _, r := range s {
		if r >= 'a' && r <= 'z' || r >= '0' && r <= '9' {
			b.WriteRune(r)
			hyphen = false
		} else if !hyphen {
			b.WriteByte('-')
			hyphen = true
		}
	}
	v := strings.Trim(b.String(), "-")
	if len(v) > 65 {
		v = v[:65]
	}
	if v == "" {
		v = "untitled"
	}
	return v
}
func folderOf(t string) (string, error) {
	x, ok := folders[t]
	if !ok {
		return "", errors.New("Unsupported entry type")
	}
	return x, nil
}
func createProject(parent, name string) (any, error) {
	if e := validName(name); e != nil {
		return nil, e
	}
	if parent == "" {
		parent = appSettings.DefaultRoot
	}
	root := filepath.Join(parent, name)
	if existing, e := os.ReadDir(root); e == nil && len(existing) > 0 {
		return nil, errors.New("The destination folder already contains files")
	}
	for _, f := range []string{"Creatures", "Magic Items", "Encounters", "Quests", "Notes", "Spells", "Characters", "Artwork", "Exports", "Backups"} {
		if e := os.MkdirAll(filepath.Join(root, f), 0755); e != nil {
			return nil, e
		}
	}
	now := time.Now().UTC().Format(time.RFC3339Nano)
	if e := writeJSON(filepath.Join(root, "forge.project.json"), map[string]any{"format": "dnd5e-forge-project", "version": 1, "name": name, "createdAt": now, "updatedAt": now}); e != nil {
		return nil, e
	}
	return openProject(root)
}
func inspectProject(root string) (map[string]any, error) {
	raw, e := os.ReadFile(filepath.Join(root, "forge.project.json"))
	if e != nil {
		return nil, errors.New("Select a DungeonScreen or Forge project containing forge.project.json")
	}
	var p map[string]any
	if json.Unmarshal(raw, &p) != nil || p["format"] != "dnd5e-forge-project" || p["version"] != float64(1) {
		return nil, errors.New("Unsupported project format")
	}
	for _, f := range []string{"Creatures", "Magic Items", "Encounters", "Quests", "Notes", "Spells", "Characters", "Artwork", "Exports", "Backups"} {
		os.MkdirAll(filepath.Join(root, f), 0755)
	}
	return map[string]any{"path": root, "name": p["name"], "version": 1}, nil
}
func openProject(root string) (any, error) {
	root, e := filepath.Abs(root)
	if e != nil {
		return nil, e
	}
	p, e := inspectProject(root)
	if e != nil {
		return nil, e
	}
	activeProject = root
	appSettings.LastProject = root
	recent := []string{root}
	for _, r := range appSettings.Recent {
		if r != root && len(recent) < 12 {
			recent = append(recent, r)
		}
	}
	appSettings.Recent = recent
	_ = storeSettings()
	return map[string]any{"project": p, "recent": recentNamed()}, nil
}
func recentNamed() []any {
	r := []any{}
	for _, p := range appSettings.Recent {
		if pr, e := inspectProject(p); e == nil {
			r = append(r, pr)
		}
	}
	return r
}
func projectRoot() (string, error) {
	if activeProject == "" {
		return "", errors.New("Open or create a project first")
	}
	return activeProject, nil
}
func docFile(root, typ, id string) (string, error) {
	folder, e := folderOf(typ)
	if e != nil {
		return "", e
	}
	if !idPat.MatchString(id) {
		return "", errors.New("Invalid entry ID")
	}
	entries, e := os.ReadDir(filepath.Join(root, folder))
	if e != nil {
		return "", e
	}
	for _, ent := range entries {
		if strings.HasSuffix(ent.Name(), "--"+id+".json") && !ent.IsDir() {
			return filepath.Join(root, folder, ent.Name()), nil
		}
	}
	return "", errors.New("Entry not found")
}
func parseDoc(path string) (Document, error) {
	var d Document
	b, e := os.ReadFile(path)
	if e != nil {
		return d, e
	}
	if len(b) > 8*1024*1024 {
		return d, errors.New("Entry exceeds 8 MB")
	}
	e = json.Unmarshal(b, &d)
	return d, e
}
func docMeta(d Document) map[string]any {
	meta := map[string]any{"id": d.ID, "type": d.Type, "name": d.Name, "updatedAt": d.UpdatedAt, "hasArt": d.Artwork != "", "color": d.Color, "artwork": d.Artwork}
	if d.Type == "spell" {
		if fields, ok := d.State["fields"].(map[string]any); ok {
			meta["school"] = fields["s_school"]
		}
	}
	return meta
}
func listDocuments(root string) (any, error) {
	out := []map[string]any{}
	for typ, folder := range folders {
		entries, _ := os.ReadDir(filepath.Join(root, folder))
		for _, ent := range entries {
			if ent.IsDir() || !strings.HasSuffix(ent.Name(), ".json") {
				continue
			}
			doc, e := parseDoc(filepath.Join(root, folder, ent.Name()))
			if e != nil || doc.Type != typ || !idPat.MatchString(doc.ID) {
				continue
			}
			meta := docMeta(doc)
			if typ == "encounter" && doc.Artwork == "" {
				if art := encounterArtwork(root, doc); art != "" {
					meta["artwork"] = art
					meta["hasArt"] = true
				}
			}
			out = append(out, meta)
		}
	}
	sort.Slice(out, func(i, j int) bool { return fmt.Sprint(out[i]["updatedAt"]) > fmt.Sprint(out[j]["updatedAt"]) })
	return out, nil
}

// The supplemental library metadata is separate from canonical entry JSON files.
// All folder paths and project membership live here as references to immutable entry IDs.
func libraryMetadata(root string) (any, error) {
	path := filepath.Join(root, "dungeonscreen.library.json")
	b, e := os.ReadFile(path)
	if errors.Is(e, os.ErrNotExist) {
		return map[string]any{"version": 1, "folders": []any{}, "placements": map[string]any{}, "labels": map[string]any{}, "projects": []any{}, "prjFolders": []any{}, "references": []any{}, "categories": map[string]any{}}, nil
	}
	if e != nil {
		return nil, e
	}
	if len(b) > 2*1024*1024 {
		return nil, errors.New("Library metadata exceeds 2 MB")
	}
	var v map[string]any
	if json.Unmarshal(b, &v) != nil || v["version"] != float64(1) {
		return nil, errors.New("Unsupported library metadata format")
	}
	return v, nil
}
func writeLibraryMetadata(root string, raw json.RawMessage) (any, error) {
	if len(raw) < 2 || len(raw) > 2*1024*1024 {
		return nil, errors.New("Invalid library metadata size")
	}
	var v map[string]any
	if json.Unmarshal(raw, &v) != nil || v["version"] != float64(1) {
		return nil, errors.New("Invalid library metadata")
	}
	for _, key := range []string{"folders", "projects", "prjFolders", "references"} {
		if _, ok := v[key].([]any); !ok {
			return nil, fmt.Errorf("Invalid %s list", key)
		}
	}
	for _, key := range []string{"placements", "labels", "categories"} {
		if _, ok := v[key].(map[string]any); !ok {
			return nil, fmt.Errorf("Invalid %s map", key)
		}
	}
	// Refuse external file paths: the metadata file contains references only.
	for _, key := range []string{"folders", "projects", "prjFolders", "references"} {
		for _, rawItem := range v[key].([]any) {
			item, ok := rawItem.(map[string]any)
			if !ok {
				return nil, errors.New("Invalid library item")
			}
			for _, prop := range []string{"id", "name", "parent", "parentId", "folderId", "projectId", "entryId", "entryType", "type", "thumbnail"} {
				if val, found := item[prop]; found {
					text, ok := val.(string)
					if !ok || len(text) > 400 || strings.ContainsAny(text, "\x00\r\n") {
						return nil, errors.New("Invalid library metadata field")
					}
				}
			}
		}
	}
	e := writeJSON(filepath.Join(root, "dungeonscreen.library.json"), v)
	return v, e
}
func cloneDocument(root, typ, id string) (any, error) {
	d, e := readDoc(root, typ, id)
	if e != nil {
		return nil, e
	}
	d.ID = ""
	d.Name = d.Name + "-copy"
	d.ImageData = ""
	return writeDoc(root, d)
}
func encounterArtwork(root string, doc Document) string {
	data, _ := doc.State["data"].(map[string]any)
	arr, _ := data["combatants"].([]any)
	bestCR := -1.0
	bestArt := ""
	for _, it := range arr {
		c, _ := it.(map[string]any)
		s, _ := c["source"].(map[string]any)
		art, _ := s["artwork"].(string)
		if art == "" {
			continue
		}
		cr, _ := strconv.ParseFloat(fmt.Sprint(c["cr"]), 64)
		if pieces := strings.SplitN(fmt.Sprint(c["cr"]), "/", 2); len(pieces) == 2 {
			top, _ := strconv.ParseFloat(strings.TrimSpace(pieces[0]), 64)
			bottom, _ := strconv.ParseFloat(strings.TrimSpace(pieces[1]), 64)
			if bottom > 0 {
				cr = top / bottom
			}
		}
		if cr > bestCR {
			bestCR = cr
			bestArt = art
		}
	}
	return bestArt
}
func readArtwork(root, ref string) (string, error) {
	if ref == "" {
		return "", nil
	}
	if !refPat.MatchString(ref) {
		return "", errors.New("Invalid artwork path")
	}
	buf, e := os.ReadFile(filepath.Join(root, filepath.FromSlash(ref)))
	if e != nil {
		return "", e
	}
	if len(buf) > 20*1024*1024 {
		return "", errors.New("Artwork too large")
	}
	ext := strings.ToLower(filepath.Ext(ref))
	mime := "image/" + strings.TrimPrefix(ext, ".")
	if ext == ".jpg" {
		mime = "image/jpeg"
	}
	return "data:" + mime + ";base64," + base64.StdEncoding.EncodeToString(buf), nil
}
func storeArtwork(root, data string) (string, error) {
	parts := strings.SplitN(data, ",", 2)
	if len(parts) != 2 || !strings.HasPrefix(parts[0], "data:image/") || !strings.HasSuffix(parts[0], ";base64") {
		return "", errors.New("Unsupported image")
	}
	mime := strings.TrimSuffix(strings.TrimPrefix(parts[0], "data:image/"), ";base64")
	switch mime {
	case "png", "jpeg", "webp", "gif":
	default:
		return "", errors.New("Use PNG, JPEG, GIF, or WebP")
	}
	if len(parts[1]) > 28*1024*1024 {
		return "", errors.New("Artwork exceeds 20 MB")
	}
	buf, e := base64.StdEncoding.DecodeString(parts[1])
	if e != nil || len(buf) == 0 || len(buf) > 20*1024*1024 {
		return "", errors.New("Invalid image data")
	}
	valid := false
	switch mime {
	case "png":
		valid = len(buf) > 8 && string(buf[1:4]) == "PNG"
	case "jpeg":
		valid = len(buf) > 3 && buf[0] == 255 && buf[1] == 216 && buf[2] == 255
	case "gif":
		valid = len(buf) > 6 && strings.HasPrefix(string(buf), "GIF8")
	case "webp":
		valid = len(buf) > 12 && string(buf[:4]) == "RIFF" && string(buf[8:12]) == "WEBP"
	}
	if !valid {
		return "", errors.New("Image content does not match image type")
	}
	ext := mime
	if ext == "jpeg" {
		ext = "jpg"
	}
	hash := sha1.Sum(buf)
	ref := "Artwork/" + hex.EncodeToString(hash[:]) + "." + ext
	dest := filepath.Join(root, filepath.FromSlash(ref))
	if _, e := os.Stat(dest); errors.Is(e, os.ErrNotExist) {
		if e = os.WriteFile(dest, buf, 0644); e != nil {
			return "", e
		}
	}
	return ref, nil
}
func snapshot(root string, doc Document) error {
	folder, _ := folderOf(doc.Type)
	dir := filepath.Join(root, "Backups", folder, doc.ID)
	if e := os.MkdirAll(dir, 0755); e != nil {
		return e
	}
	files, _ := os.ReadDir(dir)
	all := []string{}
	for _, f := range files {
		if revisionPat.MatchString(f.Name()) {
			all = append(all, f.Name())
		}
	}
	sort.Strings(all)
	if len(all) > 0 {
		info, _ := os.Stat(filepath.Join(dir, all[len(all)-1]))
		if info != nil && time.Since(info.ModTime()) < 5*time.Second {
			return nil
		}
	}
	filename := time.Now().UTC().Format("20060102T150405") + "-" + randomHex(4) + ".json"
	if e := writeJSON(filepath.Join(dir, filename), doc); e != nil {
		return e
	}
	all = append(all, filename)
	for len(all) > 20 {
		_ = os.Remove(filepath.Join(dir, all[0]))
		all = all[1:]
	}
	return nil
}
func readDoc(root, typ, id string) (Document, error) {
	file, e := docFile(root, typ, id)
	if e != nil {
		return Document{}, e
	}
	d, e := parseDoc(file)
	if e != nil {
		return d, e
	}
	if d.Artwork != "" {
		d.ImageData, _ = readArtwork(root, d.Artwork)
	}
	return d, nil
}
func writeDoc(root string, d Document) (any, error) {
	folder, e := folderOf(d.Type)
	if e != nil {
		return nil, e
	}
	d.Name = strings.TrimSpace(d.Name)
	if d.Name == "" || len(d.Name) > 160 {
		return nil, errors.New("Entry name must be 1–160 characters")
	}
	if d.State == nil {
		return nil, errors.New("Entry has no editor data")
	}
	if d.ID == "" {
		d.ID = randomHex(8)
	}
	if !idPat.MatchString(d.ID) {
		return nil, errors.New("Invalid entry ID")
	}
	var prior string
	var prev Document
	if p, e := docFile(root, d.Type, d.ID); e == nil {
		prior = p
		prev, e = parseDoc(p)
		if e != nil {
			return nil, e
		}
	}
	if d.ImageData != "" {
		ref, e := storeArtwork(root, d.ImageData)
		if e != nil {
			return nil, e
		}
		d.Artwork = ref
	}
	if d.Artwork != "" && !refPat.MatchString(d.Artwork) {
		return nil, errors.New("Invalid artwork reference")
	}
	now := time.Now().UTC().Format(time.RFC3339Nano)
	d.SchemaVersion = 1
	d.UpdatedAt = now
	if prior != "" {
		d.CreatedAt = prev.CreatedAt
	} else {
		d.CreatedAt = now
	}
	d.ImageData = ""
	if prior != "" {
		old, _ := json.Marshal(prev)
		next, _ := json.Marshal(d)
		if string(old) != string(next) {
			if e := snapshot(root, prev); e != nil {
				return nil, e
			}
		}
	}
	file := filepath.Join(root, folder, slug(d.Name)+"--"+d.ID+".json")
	if e := writeJSON(file, d); e != nil {
		return nil, e
	}
	if prior != "" && prior != file {
		_ = os.Remove(prior)
	}
	return docMeta(d), nil
}
func deleteDoc(root, typ, id string) error {
	f, e := docFile(root, typ, id)
	if e != nil {
		return e
	}
	doc, e := parseDoc(f)
	if e != nil {
		return e
	}
	if e := snapshot(root, doc); e != nil {
		return e
	}
	return os.Remove(f)
}
func revisions(root, typ, id string) (any, error) {
	folder, e := folderOf(typ)
	if e != nil {
		return nil, e
	}
	if !idPat.MatchString(id) {
		return nil, errors.New("Invalid ID")
	}
	dir := filepath.Join(root, "Backups", folder, id)
	entries, _ := os.ReadDir(dir)
	out := []map[string]any{}
	for _, ent := range entries {
		if revisionPat.MatchString(ent.Name()) {
			stat, _ := ent.Info()
			out = append(out, map[string]any{"id": ent.Name(), "createdAt": stat.ModTime().UTC().Format(time.RFC3339Nano)})
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i]["id"].(string) > out[j]["id"].(string) })
	return out, nil
}
func revisionDoc(root, typ, id, rev string) (any, error) {
	if !idPat.MatchString(id) || !revisionPat.MatchString(rev) {
		return nil, errors.New("Invalid revision")
	}
	folder, e := folderOf(typ)
	if e != nil {
		return nil, e
	}
	d, e := parseDoc(filepath.Join(root, "Backups", folder, id, rev))
	if e != nil {
		return nil, e
	}
	if d.ID != id || d.Type != typ {
		return nil, errors.New("Revision mismatch")
	}
	if d.Artwork != "" {
		d.ImageData, _ = readArtwork(root, d.Artwork)
	}
	return d, nil
}
func chooseFolder() string {
	if runtime.GOOS != "windows" {
		return ""
	}
	script := `Add-Type -AssemblyName System.Windows.Forms; $d=New-Object System.Windows.Forms.FolderBrowserDialog; $d.Description='Choose a folder for DungeonScreen'; if($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK){Write-Output $d.SelectedPath}`
	b, e := exec.Command("powershell.exe", "-NoProfile", "-STA", "-Command", script).Output()
	if e != nil {
		return ""
	}
	return strings.TrimSpace(string(b))
}
func reveal(root string) error {
	switch runtime.GOOS {
	case "windows":
		return exec.Command("explorer.exe", root).Start()
	case "darwin":
		return exec.Command("open", root).Start()
	default:
		return exec.Command("xdg-open", root).Start()
	}
}
func browserOpen(url, choice string) error {
	if runtime.GOOS == "windows" {
		if choice == "default" {
			return exec.Command("cmd", "/c", "start", "", url).Start()
		}
		candidates := []string{filepath.Join(os.Getenv("PROGRAMFILES(X86)"), "Microsoft", "Edge", "Application", "msedge.exe"), filepath.Join(os.Getenv("PROGRAMFILES"), "Microsoft", "Edge", "Application", "msedge.exe"), filepath.Join(os.Getenv("PROGRAMFILES"), "Google", "Chrome", "Application", "chrome.exe"), filepath.Join(os.Getenv("LOCALAPPDATA"), "Google", "Chrome", "Application", "chrome.exe")}
		for _, path := range candidates {
			if _, e := os.Stat(path); e == nil {
				return exec.Command(path, "--app="+url, "--window-size=1480,900").Start()
			}
		}
		return exec.Command("cmd", "/c", "start", "", url).Start()
	}
	if runtime.GOOS == "darwin" {
		return exec.Command("open", url).Start()
	}
	for _, b := range []string{"chromium", "google-chrome", "xdg-open"} {
		if path, e := exec.LookPath(b); e == nil {
			if b == "xdg-open" {
				return exec.Command(path, url).Start()
			}
			return exec.Command(path, "--app="+url, "--no-sandbox").Start()
		}
	}
	return errors.New("No available browser")
}
func jsonResult(w http.ResponseWriter, v any, e error) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	if e != nil {
		w.WriteHeader(400)
		_ = json.NewEncoder(w).Encode(map[string]any{"error": e.Error()})
		return
	}
	_ = json.NewEncoder(w).Encode(map[string]any{"ok": true, "data": v})
}
func handler(w http.ResponseWriter, r *http.Request) {
	if strings.HasPrefix(r.URL.Path, "/render/") {
		renderHandler(w, r)
		return
	}
	if r.URL.Path == "/events" {
		w.Header().Set("Content-Type", "text/event-stream")
		w.Header().Set("Cache-Control", "no-cache")
		w.Header().Set("X-Accel-Buffering", "no")
		if f, ok := w.(http.Flusher); ok {
			liveSessions.Add(1)
			everConnected.Store(true)
			defer func() { liveSessions.Add(-1); lastDisconnect.Store(time.Now().Unix()) }()
			fmt.Fprint(w, ": connected\n\n")
			f.Flush()
			<-r.Context().Done()
			return
		}
		http.Error(w, "Streaming unavailable", 500)
		return
	}
	if r.URL.Path == "/api" {
		if r.Method != "POST" {
			http.Error(w, "Method not allowed", 405)
			return
		}
		if origin := r.Header.Get("Origin"); origin != "" && !strings.HasPrefix(origin, "http://127.0.0.1:") {
			http.Error(w, "Forbidden", 403)
			return
		}
		if r.Header.Get("X-DungeonScreen") != "local-ui" {
			http.Error(w, "Forbidden", 403)
			return
		}
		r.Body = http.MaxBytesReader(w, r.Body, 28*1024*1024)
		var q Request
		if e := json.NewDecoder(r.Body).Decode(&q); e != nil {
			jsonResult(w, nil, e)
			return
		}
		appMu.Lock()
		defer appMu.Unlock()
		var data any
		var e error
		root := activeProject
		switch q.Action {
		case "session":
			var project any
			if root != "" {
				project, _ = inspectProject(root)
			}
			data = map[string]any{"project": project, "recent": recentNamed(), "settings": appSettings, "version": buildVersion}
		case "createProject":
			parent := q.Path
			if parent == "" {
				parent = appSettings.DefaultRoot
			}
			data, e = createProject(parent, q.Name)
		case "openProject":
			p := q.Path
			if p == "" {
				p = chooseFolder()
			}
			if p != "" {
				data, e = openProject(p)
			}
		case "chooseFolder":
			data = chooseFolder()
		case "folderArtwork":
			if root, e = projectRoot(); e == nil {
				var ref string
				ref, e = storeArtwork(root, q.ImageData)
				if e == nil {
					data = map[string]any{"artwork": ref}
				}
			}
		case "libraryMeta":
			if root, e = projectRoot(); e == nil {
				if len(q.Library) > 0 {
					data, e = writeLibraryMetadata(root, q.Library)
				} else {
					data, e = libraryMetadata(root)
				}
			}
		case "clone":
			if root, e = projectRoot(); e == nil {
				data, e = cloneDocument(root, q.Type, q.ID)
			}
		case "list":
			if root, e = projectRoot(); e == nil {
				data, e = listDocuments(root)
			}
		case "load":
			if root, e = projectRoot(); e == nil {
				data, e = readDoc(root, q.Type, q.ID)
			}
		case "save":
			if root, e = projectRoot(); e == nil {
				data, e = writeDoc(root, q.Document)
			}
		case "delete":
			if root, e = projectRoot(); e == nil {
				e = deleteDoc(root, q.Type, q.ID)
			}
		case "revisions":
			if root, e = projectRoot(); e == nil {
				data, e = revisions(root, q.Type, q.ID)
			}
		case "revision":
			if root, e = projectRoot(); e == nil {
				data, e = revisionDoc(root, q.Type, q.ID, q.Revision)
			}
		case "export":
			if root, e = projectRoot(); e == nil {
				data, e = exportBrowser(root, q.Filename, q.Format, q.HTML, q.Width, q.Height)
			}
		case "settings":
			wasPortable := configPath == filepath.Join(portableFolder, "settings.json")
			if q.Settings.Recent == nil {
				q.Settings.Recent = appSettings.Recent
			}
			if q.Settings.LastProject == "" {
				q.Settings.LastProject = appSettings.LastProject
			}
			appSettings = sanitizeSettings(q.Settings)
			if appSettings.Storage == "portable" {
				configPath = filepath.Join(portableFolder, "settings.json")
			} else {
				configPath = userConfigPath()
			}
			e = storeSettings()
			if e == nil && wasPortable && appSettings.Storage != "portable" {
				_ = os.Remove(filepath.Join(portableFolder, "settings.json"))
			}
			data = appSettings
		case "reveal":
			if root, e = projectRoot(); e == nil {
				e = reveal(root)
			}
		case "detach": // Native app window when Edge/Chrome is available, fallback browser window.
			if !strings.HasPrefix(q.Path, "http://127.0.0.1:") || (!strings.Contains(q.Path, "?panel=editor") && !strings.Contains(q.Path, "?panel=preview")) {
				e = errors.New("Invalid window URL")
			} else {
				data = map[string]any{"url": q.Path}
				e = browserOpen(q.Path, appSettings.Browser)
			}
		default:
			e = errors.New("Unknown command")
		}
		jsonResult(w, data, e)
		return
	}
	if r.URL.Path == "/art" {
		if activeProject == "" {
			http.NotFound(w, r)
			return
		}
		ref := r.URL.Query().Get("ref")
		if !refPat.MatchString(ref) {
			http.NotFound(w, r)
			return
		}
		file := filepath.Join(activeProject, filepath.FromSlash(ref))
		w.Header().Set("Cache-Control", "public,max-age=3600")
		http.ServeFile(w, r, file)
		return
	}
	if r.URL.Path == "/" {
		r.URL.Path = "/index.html"
	}
	path := strings.TrimPrefix(filepath.ToSlash(filepath.Clean(r.URL.Path)), "/")
	content, e := fs.ReadFile(webFiles, "app/"+path)
	if e != nil {
		http.NotFound(w, r)
		return
	}
	switch filepath.Ext(path) {
	case ".html":
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
	case ".js":
		w.Header().Set("Content-Type", "text/javascript; charset=utf-8")
	case ".css":
		w.Header().Set("Content-Type", "text/css; charset=utf-8")
	}
	w.Header().Set("Cache-Control", "no-store")
	_, _ = w.Write(content)
}
func main() {
	exe, _ := os.Executable()
	portableFolder = filepath.Join(filepath.Dir(exe), "DungeonScreen Data")
	configPath = userConfigPath()
	if _, e := os.Stat(filepath.Join(portableFolder, "settings.json")); e == nil {
		configPath = filepath.Join(portableFolder, "settings.json")
	}
	appSettings = readSettings(configPath)
	if appSettings.LastProject != "" {
		if _, e := inspectProject(appSettings.LastProject); e == nil {
			activeProject = appSettings.LastProject
		}
	}
	listener, e := net.Listen("tcp", "127.0.0.1:0")
	if e != nil {
		log.Fatal(e)
	}
	listenerAddress(listener)
	url := "http://" + listener.Addr().String() + "/"
	http.HandleFunc("/", handler)
	go func() {
		ticker := time.NewTicker(5 * time.Second)
		defer ticker.Stop()
		for range ticker.C {
			if everConnected.Load() && liveSessions.Load() == 0 && time.Now().Unix()-lastDisconnect.Load() > 25 {
				os.Exit(0)
			}
		}
	}()
	go func() {
		if e := http.Serve(listener, nil); e != nil {
			log.Println(e)
		}
	}()
	fmt.Println("DungeonScreen", buildVersion, url)
	if e := browserOpen(url, appSettings.Browser); e != nil {
		fmt.Println("Open this address in your browser:", url)
	}
	select {}
}
